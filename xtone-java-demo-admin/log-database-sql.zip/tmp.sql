/*
SQLyog Community v11.1 (64 bit)
MySQL - 5.6.24-log : Database - log_general
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`log_general` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `log_general`;

/*Table structure for table `log_async_16` */

DROP TABLE IF EXISTS `log_async_16`;

CREATE TABLE `log_async_16` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MRG_MyISAM DEFAULT CHARSET=utf8 INSERT_METHOD=LAST UNION=(`z160114a`,`z160115a`,`z160116a`,`z160117a`,`z160118a`,`z160119a`,`z160120a`,`z160121a`,`z160122a`,`z160123a`,`z160124a`,`z160125a`,`z160126a`,`z160127a`,`z160128a`,`z160129a`,`z160130a`,`z160131a`,`z160201a`,`z160202a`,`z160203a`,`z160204a`,`z160205a`,`z160206a`,`z160207a`,`z160208a`,`z160209a`,`z160210a`,`z160211a`,`z160212a`,`z160213a`,`z160214a`,`z160215a`,`z160216a`,`z160217a`,`z160218a`,`z160219a`,`z160220a`,`z160221a`,`z160222a`,`z160223a`,`z160224a`,`z160225a`,`z160226a`,`z160227a`,`z160228a`,`z160229a`,`z160301a`,`z160302a`,`z160303a`,`z160304a`,`z160305a`,`z160306a`,`z160307a`,`z160308a`,`z160309a`,`z160310a`,`z160311a`,`z160312a`,`z160313a`,`z160314a`,`z160315a`,`z160316a`,`z160317a`,`z160318a`,`z160319a`,`z160320a`,`z160321a`,`z160322a`,`z160323a`,`z160324a`,`z160325a`,`z160326a`,`z160327a`,`z160328a`,`z160329a`,`z160330a`,`z160331a`,`z160401a`,`z160402a`,`z160403a`,`z160404a`,`z160405a`,`z160406a`,`z160407a`,`z160408a`,`z160409a`,`z160410a`,`z160411a`,`z160412a`,`z160413a`,`z160414a`,`z160415a`,`z160416a`,`z160417a`,`z160418a`,`z160419a`,`z160420a`,`z160421a`,`z160422a`,`z160423a`,`z160424a`,`z160425a`,`z160426a`,`z160427a`,`z160428a`,`z160429a`,`z160430a`,`z160501a`,`z160502a`,`z160503a`,`z160504a`,`z160505a`,`z160506a`,`z160507a`,`z160508a`,`z160509a`,`z160510a`,`z160511a`,`z160512a`,`z160513a`,`z160514a`,`z160515a`,`z160516a`,`z160517a`,`z160518a`,`z160519a`,`z160520a`,`z160521a`,`z160522a`,`z160523a`,`z160524a`,`z160525a`,`z160526a`,`z160527a`,`z160528a`,`z160529a`,`z160530a`,`z160531a`,`z160601a`,`z160602a`,`z160603a`,`z160604a`,`z160605a`,`z160606a`,`z160607a`,`z160608a`,`z160609a`,`z160610a`,`z160611a`,`z160612a`,`z160613a`,`z160614a`,`z160615a`,`z160616a`,`z160617a`,`z160618a`,`z160619a`,`z160620a`,`z160621a`,`z160622a`,`z160623a`,`z160624a`,`z160625a`,`z160626a`,`z160627a`,`z160628a`);

/*Table structure for table `log_async_1606` */

DROP TABLE IF EXISTS `log_async_1606`;

CREATE TABLE `log_async_1606` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MRG_MyISAM DEFAULT CHARSET=utf8 INSERT_METHOD=LAST UNION=(`z160531a`,`z160601a`,`z160602a`,`z160603a`,`z160604a`,`z160605a`,`z160606a`,`z160607a`,`z160608a`,`z160609a`,`z160610a`,`z160611a`,`z160612a`,`z160613a`,`z160614a`,`z160615a`,`z160616a`,`z160617a`,`z160618a`,`z160619a`,`z160620a`,`z160621a`,`z160622a`,`z160623a`,`z160624a`,`z160625a`,`z160626a`,`z160627a`,`z160628a`);

/*Table structure for table `log_async_generals` */

DROP TABLE IF EXISTS `log_async_generals`;

CREATE TABLE `log_async_generals` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MRG_MyISAM DEFAULT CHARSET=utf8 INSERT_METHOD=LAST UNION=(`z160627a`,`z160628a`);

/*Table structure for table `log_async_last_hundred_days` */

DROP TABLE IF EXISTS `log_async_last_hundred_days`;

CREATE TABLE `log_async_last_hundred_days` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MRG_MyISAM DEFAULT CHARSET=utf8 UNION=(`z160321a`,`z160322a`,`z160323a`,`z160324a`,`z160325a`,`z160326a`,`z160327a`,`z160328a`,`z160329a`,`z160330a`,`z160331a`,`z160401a`,`z160402a`,`z160403a`,`z160404a`,`z160405a`,`z160406a`,`z160407a`,`z160408a`,`z160409a`,`z160410a`,`z160411a`,`z160412a`,`z160413a`,`z160414a`,`z160415a`,`z160416a`,`z160417a`,`z160418a`,`z160419a`,`z160420a`,`z160421a`,`z160422a`,`z160423a`,`z160424a`,`z160425a`,`z160426a`,`z160427a`,`z160428a`,`z160429a`,`z160430a`,`z160501a`,`z160502a`,`z160503a`,`z160504a`,`z160505a`,`z160506a`,`z160507a`,`z160508a`,`z160509a`,`z160510a`,`z160511a`,`z160512a`,`z160513a`,`z160514a`,`z160515a`,`z160516a`,`z160517a`,`z160518a`,`z160519a`,`z160520a`,`z160521a`,`z160522a`,`z160523a`,`z160524a`,`z160525a`,`z160526a`,`z160527a`,`z160528a`,`z160529a`,`z160530a`,`z160531a`,`z160601a`,`z160602a`,`z160603a`,`z160604a`,`z160605a`,`z160606a`,`z160607a`,`z160608a`,`z160609a`,`z160610a`,`z160611a`,`z160612a`,`z160613a`,`z160614a`,`z160615a`,`z160616a`,`z160617a`,`z160618a`,`z160619a`,`z160620a`,`z160621a`,`z160622a`,`z160623a`,`z160624a`,`z160625a`,`z160626a`,`z160627a`,`z160628a`);

/*Table structure for table `log_sync_16` */

DROP TABLE IF EXISTS `log_sync_16`;

CREATE TABLE `log_sync_16` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MRG_MyISAM DEFAULT CHARSET=utf8 INSERT_METHOD=LAST UNION=(`z160114b`,`z160115b`,`z160116b`,`z160117b`,`z160118b`,`z160119b`,`z160120b`,`z160121b`,`z160122b`,`z160123b`,`z160124b`,`z160125b`,`z160126b`,`z160127b`,`z160128b`,`z160129b`,`z160130b`,`z160131b`,`z160201b`,`z160202b`,`z160203b`,`z160204b`,`z160205b`,`z160206b`,`z160207b`,`z160208b`,`z160209b`,`z160210b`,`z160211b`,`z160212b`,`z160213b`,`z160214b`,`z160215b`,`z160216b`,`z160217b`,`z160218b`,`z160219b`,`z160220b`,`z160221b`,`z160222b`,`z160223b`,`z160224b`,`z160225b`,`z160226b`,`z160227b`,`z160228b`,`z160229b`,`z160301b`,`z160302b`,`z160303b`,`z160304b`,`z160305b`,`z160306b`,`z160307b`,`z160308b`,`z160309b`,`z160310b`,`z160311b`,`z160312b`,`z160313b`,`z160314b`,`z160315b`,`z160316b`,`z160317b`,`z160318b`,`z160319b`,`z160320b`,`z160321b`,`z160322b`,`z160323b`,`z160324b`,`z160325b`,`z160326b`,`z160327b`,`z160328b`,`z160329b`,`z160330b`,`z160331b`,`z160401b`,`z160402b`,`z160403b`,`z160404b`,`z160405b`,`z160406b`,`z160407b`,`z160408b`,`z160409b`,`z160410b`,`z160411b`,`z160412b`,`z160413b`,`z160414b`,`z160415b`,`z160416b`,`z160417b`,`z160418b`,`z160419b`,`z160420b`,`z160421b`,`z160422b`,`z160423b`,`z160424b`,`z160425b`,`z160426b`,`z160427b`,`z160428b`,`z160429b`,`z160430b`,`z160501b`,`z160502b`,`z160503b`,`z160504b`,`z160505b`,`z160506b`,`z160507b`,`z160508b`,`z160509b`,`z160510b`,`z160511b`,`z160512b`,`z160513b`,`z160514b`,`z160515b`,`z160516b`,`z160517b`,`z160518b`,`z160519b`,`z160520b`,`z160521b`,`z160522b`,`z160523b`,`z160524b`,`z160525b`,`z160526b`,`z160527b`,`z160528b`,`z160529b`,`z160530b`,`z160531b`,`z160601b`,`z160602b`,`z160603b`,`z160604b`,`z160605b`,`z160606b`,`z160607b`,`z160608b`,`z160609b`,`z160610b`,`z160611b`,`z160612b`,`z160613b`,`z160614b`,`z160615b`,`z160616b`,`z160617b`,`z160618b`,`z160619b`,`z160620b`,`z160621b`,`z160622b`,`z160623b`,`z160624b`,`z160625b`,`z160626b`,`z160627b`,`z160628b`);

/*Table structure for table `log_sync_1606` */

DROP TABLE IF EXISTS `log_sync_1606`;

CREATE TABLE `log_sync_1606` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MRG_MyISAM DEFAULT CHARSET=utf8 INSERT_METHOD=LAST UNION=(`z160531b`,`z160601b`,`z160602b`,`z160603b`,`z160604b`,`z160605b`,`z160606b`,`z160607b`,`z160608b`,`z160609b`,`z160610b`,`z160611b`,`z160612b`,`z160613b`,`z160614b`,`z160615b`,`z160616b`,`z160617b`,`z160618b`,`z160619b`,`z160620b`,`z160621b`,`z160622b`,`z160623b`,`z160624b`,`z160625b`,`z160626b`,`z160627b`,`z160628b`);

/*Table structure for table `log_sync_generals` */

DROP TABLE IF EXISTS `log_sync_generals`;

CREATE TABLE `log_sync_generals` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MRG_MyISAM DEFAULT CHARSET=utf8 INSERT_METHOD=LAST UNION=(`z160627b`,`z160628b`);

/*Table structure for table `log_sync_last_hundred_days` */

DROP TABLE IF EXISTS `log_sync_last_hundred_days`;

CREATE TABLE `log_sync_last_hundred_days` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MRG_MyISAM DEFAULT CHARSET=utf8 UNION=(`z160321b`,`z160322b`,`z160323b`,`z160324b`,`z160325b`,`z160326b`,`z160327b`,`z160328b`,`z160329b`,`z160330b`,`z160331b`,`z160401b`,`z160402b`,`z160403b`,`z160404b`,`z160405b`,`z160406b`,`z160407b`,`z160408b`,`z160409b`,`z160410b`,`z160411b`,`z160412b`,`z160413b`,`z160414b`,`z160415b`,`z160416b`,`z160417b`,`z160418b`,`z160419b`,`z160420b`,`z160421b`,`z160422b`,`z160423b`,`z160424b`,`z160425b`,`z160426b`,`z160427b`,`z160428b`,`z160429b`,`z160430b`,`z160501b`,`z160502b`,`z160503b`,`z160504b`,`z160505b`,`z160506b`,`z160507b`,`z160508b`,`z160509b`,`z160510b`,`z160511b`,`z160512b`,`z160513b`,`z160514b`,`z160515b`,`z160516b`,`z160517b`,`z160518b`,`z160519b`,`z160520b`,`z160521b`,`z160522b`,`z160523b`,`z160524b`,`z160525b`,`z160526b`,`z160527b`,`z160528b`,`z160529b`,`z160530b`,`z160531b`,`z160601b`,`z160602b`,`z160603b`,`z160604b`,`z160605b`,`z160606b`,`z160607b`,`z160608b`,`z160609b`,`z160610b`,`z160611b`,`z160612b`,`z160613b`,`z160614b`,`z160615b`,`z160616b`,`z160617b`,`z160618b`,`z160619b`,`z160620b`,`z160621b`,`z160622b`,`z160623b`,`z160624b`,`z160625b`,`z160626b`,`z160627b`,`z160628b`);

/*Table structure for table `z160627a` */

DROP TABLE IF EXISTS `z160627a`;

CREATE TABLE `z160627a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160627b` */

DROP TABLE IF EXISTS `z160627b`;

CREATE TABLE `z160627b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160628a` */

DROP TABLE IF EXISTS `z160628a`;

CREATE TABLE `z160628a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160628b` */

DROP TABLE IF EXISTS `z160628b`;

CREATE TABLE `z160628b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!50106 set global event_scheduler = 1*/;

/* Event structure for event `run_add_converge_100day_table` */

/*!50106 DROP EVENT IF EXISTS `run_add_converge_100day_table`*/;

DELIMITER $$

/*!50106 CREATE DEFINER=`root`@`localhost` EVENT `run_add_converge_100day_table` ON SCHEDULE EVERY 1 DAY STARTS '2016-04-15 00:05:00' ON COMPLETION NOT PRESERVE ENABLE DO call log_general.converge_100day_table() */$$
DELIMITER ;

/* Event structure for event `run_add_converge_month_table` */

/*!50106 DROP EVENT IF EXISTS `run_add_converge_month_table`*/;

DELIMITER $$

/*!50106 CREATE DEFINER=`root`@`localhost` EVENT `run_add_converge_month_table` ON SCHEDULE EVERY 1 DAY STARTS '2016-04-15 00:07:00' ON COMPLETION NOT PRESERVE ENABLE DO call log_general.converge_month_table() */$$
DELIMITER ;

/* Event structure for event `run_add_converge_year_table` */

/*!50106 DROP EVENT IF EXISTS `run_add_converge_year_table`*/;

DELIMITER $$

/*!50106 CREATE DEFINER=`root`@`localhost` EVENT `run_add_converge_year_table` ON SCHEDULE EVERY 1 DAY STARTS '2016-04-15 00:09:00' ON COMPLETION NOT PRESERVE ENABLE DO call log_general.converge_year_table() */$$
DELIMITER ;

/* Event structure for event `run_add_table` */

/*!50106 DROP EVENT IF EXISTS `run_add_table`*/;

DELIMITER $$

/*!50106 CREATE DEFINER=`root`@`localhost` EVENT `run_add_table` ON SCHEDULE EVERY 1 DAY STARTS '2016-01-16 00:00:00' ON COMPLETION NOT PRESERVE ENABLE DO call add_table() */$$
DELIMITER ;

/* Procedure structure for procedure `add_table` */

/*!50003 DROP PROCEDURE IF EXISTS  `add_table` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `add_table`()
BEGIN
    set @today = date_format(date(now()),'%y%m%d');
    set @yesterday = date_format(date_add(now(), interval -1 day),'%y%m%d');
    set @tb_namea = concat('z',@today,'a');
    set @old_tb_namea = concat('z',@yesterday,'a');
    set @old_tb_nameb = concat('z',@yesterday,'b');
    set @tb_nameb = concat('z',@today,'b'); 
    DROP TABLE IF EXISTS log_general.log_async_generals;
    DROP TABLE IF EXISTS log_general.log_sync_generals;
    
    create table log_general.log_sync_generals(
        `id` BIGINT(20) NOT NULL COMMENT '通用日志表',
        `logId` INT(11) DEFAULT NULL COMMENT '对应表在配置库中',
        `para01` TEXT,
        `para02` TEXT,
        `para03` TEXT,
        `para04` TEXT,
        `para05` TEXT,
        `para06` TEXT,
        `para07` TEXT,
        `para08` TEXT,
        `para09` TEXT,
        `para10` TEXT,
        `para11` TEXT,
        `para12` TEXT,
        `para13` TEXT,
        `para14` TEXT,
        `para15` TEXT,
        `para16` TEXT,
        `para17` TEXT,
        `para18` TEXT,
        `para19` TEXT,
        `para20` TEXT,
        PRIMARY KEY (`id`),
        KEY `idx_logId` (`logId`)) engine=mrg_myisam union=() insert_method=last;
    create table log_general.log_async_generals(
        `id` BIGINT(20) NOT NULL COMMENT '通用日志表',
        `logId` INT(11) DEFAULT NULL COMMENT '对应表在配置库中',
        `para01` TEXT,
        `para02` TEXT,
        `para03` TEXT,
        `para04` TEXT,
        `para05` TEXT,
        `para06` TEXT,
        `para07` TEXT,
        `para08` TEXT,
        `para09` TEXT,
        `para10` TEXT,
        `para11` TEXT,
        `para12` TEXT,
        `para13` TEXT,
        `para14` TEXT,
        `para15` TEXT,
        `para16` TEXT,
        `para17` TEXT,
        `para18` TEXT,
        `para19` TEXT,
        `para20` TEXT,
        PRIMARY KEY (`id`),
        KEY `idx_logId` (`logId`)) engine=mrg_myisam union=() insert_method=last;
        
        
    set @sql_add_tablea_text = concat(
        "CREATE TABLE ",@tb_namea," (
            `id` BIGINT(20) NOT NULL COMMENT '通用日志表',
            `logId` INT(11) DEFAULT NULL COMMENT '对应表在配置库中',
            `para01` TEXT,
            `para02` TEXT,
            `para03` TEXT,
            `para04` TEXT,
            `para05` TEXT,
            `para06` TEXT,
            `para07` TEXT,
            `para08` TEXT,
            `para09` TEXT,
            `para10` TEXT,
            `para11` TEXT,
            `para12` TEXT,
            `para13` TEXT,
            `para14` TEXT,
            `para15` TEXT,
            `para16` TEXT,
            `para17` TEXT,
            `para18` TEXT,
            `para19` TEXT,
            `para20` TEXT,
            PRIMARY KEY (`id`),
            KEY `idx_logId` (`logId`)
        )
        ENGINE=MYISAM DEFAULT CHARSET=utf8;"
    );
    set @sql_add_tableb_text = concat(
        "CREATE TABLE ",@tb_nameb," (
            `id` BIGINT(20) NOT NULL COMMENT '通用日志表',
            `logId` INT(11) DEFAULT NULL COMMENT '对应表在配置库中',
            `para01` TEXT,
            `para02` TEXT,
            `para03` TEXT,
            `para04` TEXT,
            `para05` TEXT,
            `para06` TEXT,
            `para07` TEXT,
            `para08` TEXT,
            `para09` TEXT,
            `para10` TEXT,
            `para11` TEXT,
            `para12` TEXT,
            `para13` TEXT,
            `para14` TEXT,
            `para15` TEXT,
            `para16` TEXT,
            `para17` TEXT,
            `para18` TEXT,
            `para19` TEXT,
            `para20` TEXT,
            PRIMARY KEY (`id`),
            KEY `idx_logId` (`logId`)
        )
        ENGINE=MYISAM DEFAULT CHARSET=utf8;"
    );
    set @sql_alt_mrga_text = concat(
        "ALTER TABLE log_async_generals engine=mrg_myisam union=(",@old_tb_namea,",",@tb_namea,") insert_method=last;"
    );
    set @sql_alt_mrgb_text = concat(
        "ALTER TABLE log_sync_generals engine=mrg_myisam union=(",@old_tb_nameb,",",@tb_nameb,") insert_method=last;"
    );
    
    PREPARE statement_namea FROM @sql_add_tablea_text;
    PREPARE statement_nameb FROM @sql_add_tableb_text;
    EXECUTE statement_namea;
    EXECUTE statement_nameb;
    DEALLOCATE PREPARE statement_namea;
    DEALLOCATE PREPARE statement_nameb;
    
    
    PREPARE alt_mrg_a FROM @sql_alt_mrga_text;
    PREPARE alt_mrg_b FROM @sql_alt_mrgb_text;
    EXECUTE alt_mrg_a;
    EXECUTE alt_mrg_b;
    DEALLOCATE PREPARE alt_mrg_a;
    DEALLOCATE PREPARE alt_mrg_b;
END */$$
DELIMITER ;

/* Procedure structure for procedure `converge_100day_table` */

/*!50003 DROP PROCEDURE IF EXISTS  `converge_100day_table` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `converge_100day_table`()
BEGIN
    set @databases = 'log_general';
    set @day_num=0;
    set @range_day_num=99;
    set @atable_name='';
    set @all_atables='';
    set @out=@day_num;
    repeat
        set @next_day = date_format(date_add(now(), interval -@day_num day),'%y%m%d');
        set @atable_name = concat('z',@next_day ,'a');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@atable_name)
            then
                set @all_atables=@atable_name;
                set @out=@range_day_num;
        end if;
        set @out=@out+1;
        set @day_num=@day_num+1;
        until @out > @range_day_num
    end repeat;
    
    repeat
        set @next_day = date_format(date_add(now(), interval -@day_num day),'%y%m%d');
        set @atable_name = concat('z',@next_day ,'a');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@atable_name) && (@all_atables != @atable_name)
            then
                set @all_atables = concat_ws(',',@atable_name,@all_atables);
        end if;
        set @day_num=@day_num + 1;
        until @day_num > @range_day_num
    end repeat;
    
    set @day_num=0;
    set @range_day_num=99;
    set @btable_name='';
    set @all_btables='';
    set @out=@day_num;
    repeat
        set @next_day = date_format(date_add(now(), interval -@day_num day),'%y%m%d');
        set @btable_name = concat('z',@next_day ,'b');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@btable_name)
            then
                set @all_btables=@btable_name;
                set @out=@range_day_num;
        end if;
        set @out=@out+1;
        set @day_num=@day_num+1;
        until @out > @range_day_num
    end repeat;
    
    repeat
        set @next_day = date_format(date_add(now(), interval -@day_num day),'%y%m%d');
        set @btable_name = concat('z',@next_day ,'b');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@btable_name) && (@all_btables != @btable_name)
            then
                set @all_btables = concat_ws(',',@btable_name,@all_btables);
        end if;
        set @day_num=@day_num + 1;
        until @day_num > @range_day_num
    end repeat;    
    set @atablename = concat('log_async_','last_hundred_days');
    set @full_aname = concat_ws('.',@databases,@atablename);
    set @btablename = concat('log_sync_','last_hundred_days');
    set @full_bname = concat_ws('.',@databases,@btablename);
 
    set @if_existe_drop_tablea = concat("
    DROP TABLE IF EXISTS ",@full_aname,";
    ");
    
    set @if_existe_drop_tableb = concat("
    DROP TABLE IF EXISTS ",@full_bname,";
    ");
    
    PREPARE drop_tablea FROM @if_existe_drop_tablea;
    PREPARE drop_tableb FROM @if_existe_drop_tableb;
    EXECUTE drop_tablea;
    EXECUTE drop_tableb;
    DEALLOCATE PREPARE drop_tablea;
    DEALLOCATE PREPARE drop_tableb;

    
    set @sql_add_converge_btable = concat("
    create table ",@full_bname,"(
        `id` BIGINT(20) NOT NULL COMMENT '通用日志表',
        `logId` INT(11) DEFAULT NULL COMMENT '对应表在配置库中',
        `para01` TEXT,
        `para02` TEXT,
        `para03` TEXT,
        `para04` TEXT,
        `para05` TEXT,
        `para06` TEXT,
        `para07` TEXT,
        `para08` TEXT,
        `para09` TEXT,
        `para10` TEXT,
        `para11` TEXT,
        `para12` TEXT,
        `para13` TEXT,
        `para14` TEXT,
        `para15` TEXT,
        `para16` TEXT,
        `para17` TEXT,
        `para18` TEXT,
        `para19` TEXT,
        `para20` TEXT,
        PRIMARY KEY (`id`),
        KEY `idx_logId` (`logId`)) engine=mrg_myisam union=() insert_method=last;
        ");
    
    set @sql_add_converge_atable = concat("
    create table ",@full_aname,"(
        `id` BIGINT(20) NOT NULL COMMENT '通用日志表',
        `logId` INT(11) DEFAULT NULL COMMENT '对应表在配置库中',
        `para01` TEXT,
        `para02` TEXT,
        `para03` TEXT,
        `para04` TEXT,
        `para05` TEXT,
        `para06` TEXT,
        `para07` TEXT,
        `para08` TEXT,
        `para09` TEXT,
        `para10` TEXT,
        `para11` TEXT,
        `para12` TEXT,
        `para13` TEXT,
        `para14` TEXT,
        `para15` TEXT,
        `para16` TEXT,
        `para17` TEXT,
        `para18` TEXT,
        `para19` TEXT,
        `para20` TEXT,
        PRIMARY KEY (`id`),
        KEY `idx_logId` (`logId`)) engine=mrg_myisam union=() insert_method=last;
        ");
        
        
    PREPARE creat_tablea FROM @sql_add_converge_atable;
    PREPARE creat_tableb FROM @sql_add_converge_btable;
    EXECUTE creat_tablea;
    EXECUTE creat_tableb;
    DEALLOCATE PREPARE creat_tablea;
    DEALLOCATE PREPARE creat_tableb;

    
    set @sql_alt_mrga_hundred_days = concat(
        "ALTER TABLE ",@full_aname," engine=mrg_myisam union=(",@all_atables,") insert_method=no;"
    );
    set @sql_alt_mrgb_hundred_days = concat(
        "ALTER TABLE ",@full_bname," engine=mrg_myisam union=(",@all_btables,") insert_method=no;"
    );

    PREPARE alt_mrg_a FROM @sql_alt_mrga_hundred_days;
    PREPARE alt_mrg_b FROM @sql_alt_mrgb_hundred_days;
    EXECUTE alt_mrg_a;
    EXECUTE alt_mrg_b;
    DEALLOCATE PREPARE alt_mrg_a;
    DEALLOCATE PREPARE alt_mrg_b;
    
END */$$
DELIMITER ;

/* Procedure structure for procedure `converge_month_table` */

/*!50003 DROP PROCEDURE IF EXISTS  `converge_month_table` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `converge_month_table`()
BEGIN
    
    set @databases = 'log_general';
    set @today = date_format(now(),'%y%m%d');
    set @last_or_this_month = '';
    if  day(@today) = 1
    then
        set @last_or_this_month = date_format(date_add(@today, interval -1 month),'%y%m%d');
    else
        set @last_or_this_month = date_format(date_add(@today, interval 0 month),'%y%m%d');
    end if;
    set @last_last_or_this_month = date_format(date_add(@last_or_this_month, interval -1 month),'%y%m%d');
    set @last_or_this_month_lastday = date_format(last_day(@last_last_or_this_month),'%y%m%d');
    set @this_or_next_month_firstday = date_format(date_add(last_day(@last_or_this_month),interval 1 day),'%y%m%d');
    set @range_day_num = to_days(@this_or_next_month_firstday) - to_days(@last_or_this_month_lastday);
    
    set @day_num = 0;
    set @out = @day_num;
    set @all_atables = "";
    set @next_day = "";
    repeat
        set @next_day = date_format(date_add(@last_or_this_month_lastday, interval @day_num day),'%y%m%d');
        set @atable_name = concat('z',@next_day ,'a');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@atable_name)
            then
                set @all_atables=@atable_name;
                set @out=@range_day_num;
        end if;
        set @out=@out+1;
        set @day_num=@day_num+1;
        until @out > @range_day_num
    end repeat;
    
    repeat
        set @next_day = date_format(date_add(@last_or_this_month_lastday, interval @day_num day),'%y%m%d');
        set @atable_name = concat('z',@next_day ,'a');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@atable_name) && (@all_atables != @atable_name)
            then
                set @all_atables = concat_ws(',',@all_atables,@atable_name);
        end if;
        set @day_num=@day_num + 1;
        until @day_num > @range_day_num
    end repeat;

    
    set @day_num = 0;
    set @out = @day_num;
    set @all_btables = "";
    set @next_day = "";
    repeat
        set @next_day = date_format(date_add(@last_or_this_month_lastday, interval @day_num day),'%y%m%d');
        set @btable_name = concat('z',@next_day ,'b');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@btable_name)
            then
                set @all_btables=@btable_name;
                set @out=@range_day_num;
        end if;
        set @out=@out+1;
        set @day_num=@day_num+1;
        until @out > @range_day_num
    end repeat;
    
    repeat
        set @next_day = date_format(date_add(@last_or_this_month_lastday, interval @day_num day),'%y%m%d');
        set @btable_name = concat('z',@next_day ,'b');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@btable_name) && (@all_btables != @btable_name)
            then
                set @all_btables = concat_ws(',',@all_btables,@btable_name);
        end if;
        set @day_num=@day_num + 1;
        until @day_num > @range_day_num
    end repeat;

    set @atablename = concat('log_async_',date_format(@last_or_this_month,'%y%m'));
    set @full_aname = concat_ws('.',@databases,@atablename);
    set @btablename = concat('log_sync_',date_format(@last_or_this_month,'%y%m'));
    set @full_bname = concat_ws('.',@databases,@btablename);
 
    set @if_existe_drop_tablea = concat("
    DROP TABLE IF EXISTS ",@full_aname,";
    ");
    
    set @if_existe_drop_tableb = concat("
    DROP TABLE IF EXISTS ",@full_bname,";
    ");
    
    PREPARE drop_tablea FROM @if_existe_drop_tablea;
    PREPARE drop_tableb FROM @if_existe_drop_tableb;
    EXECUTE drop_tablea;
    EXECUTE drop_tableb;
    DEALLOCATE PREPARE drop_tablea;
    DEALLOCATE PREPARE drop_tableb;
    
    
    set @sql_add_converge_btable = concat("
    create table ",@full_bname,"(
        `id` BIGINT(20) NOT NULL COMMENT '通用日志表',
        `logId` INT(11) DEFAULT NULL COMMENT '对应表在配置库中',
        `para01` TEXT,
        `para02` TEXT,
        `para03` TEXT,
        `para04` TEXT,
        `para05` TEXT,
        `para06` TEXT,
        `para07` TEXT,
        `para08` TEXT,
        `para09` TEXT,
        `para10` TEXT,
        `para11` TEXT,
        `para12` TEXT,
        `para13` TEXT,
        `para14` TEXT,
        `para15` TEXT,
        `para16` TEXT,
        `para17` TEXT,
        `para18` TEXT,
        `para19` TEXT,
        `para20` TEXT,
        PRIMARY KEY (`id`),
        KEY `idx_logId` (`logId`)) engine=mrg_myisam union=() insert_method=last;
        ");
    set @sql_add_converge_atable =concat("
    create table ",@full_aname,"(
        `id` BIGINT(20) NOT NULL COMMENT '通用日志表',
        `logId` INT(11) DEFAULT NULL COMMENT '对应表在配置库中',
        `para01` TEXT,
        `para02` TEXT,
        `para03` TEXT,
        `para04` TEXT,
        `para05` TEXT,
        `para06` TEXT,
        `para07` TEXT,
        `para08` TEXT,
        `para09` TEXT,
        `para10` TEXT,
        `para11` TEXT,
        `para12` TEXT,
        `para13` TEXT,
        `para14` TEXT,
        `para15` TEXT,
        `para16` TEXT,
        `para17` TEXT,
        `para18` TEXT,
        `para19` TEXT,
        `para20` TEXT,
        PRIMARY KEY (`id`),
        KEY `idx_logId` (`logId`)) engine=mrg_myisam union=() insert_method=last;
    ");
        
    set @sql_alt_mrga_text = concat(
        "ALTER TABLE ",@atablename," engine=mrg_myisam union=(",@all_atables,") insert_method=last;"
    );
    set @sql_alt_mrgb_text = concat(
        "ALTER TABLE ",@btablename," engine=mrg_myisam union=(",@all_btables,") insert_method=last;"
    );
    
    PREPARE creat_tablea FROM @sql_add_converge_atable;
    PREPARE creat_tableb FROM @sql_add_converge_btable;
    EXECUTE creat_tablea;
    EXECUTE creat_tableb;
    DEALLOCATE PREPARE creat_tablea;
    DEALLOCATE PREPARE creat_tableb;
    
    PREPARE alt_mrg_a FROM @sql_alt_mrga_text;
    PREPARE alt_mrg_b FROM @sql_alt_mrgb_text;
    EXECUTE alt_mrg_a;
    EXECUTE alt_mrg_b;
    DEALLOCATE PREPARE alt_mrg_a;
    DEALLOCATE PREPARE alt_mrg_b;
END */$$
DELIMITER ;

/* Procedure structure for procedure `converge_year_table` */

/*!50003 DROP PROCEDURE IF EXISTS  `converge_year_table` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `converge_year_table`()
BEGIN
    
    set @databases = 'log_general';
    set @today = date_format(now(),'%y%m%d');
    set @this_or_next_year = '';
    if date_format(@today,'%m%d') = '0101'
    then
        set @this_or_next_year = date_format(date_add(@today, interval -1 year),'%y%m%d');
    else
        set @this_or_next_year = date_format(date_add(@today, interval 0 year),'%y%m%d');
    end if;
    
    set @last_this_or_next_year = date_format(date_add(@this_or_next_year, interval -1 year),'%y%m%d');
    set @this_or_next_year_lastday = concat(date_format(@last_this_or_next_year,'%y'),'1231');
    
    set @this_or_next_year_firstday = concat(date_format(date_add(@this_or_next_year,interval 1 year),'%y'),'0101');


    set @range_day_num = to_days(@this_or_next_year_firstday) - to_days(@this_or_next_year_lastday);
    
    
    
    set @day_num = 0;
    set @out = @day_num;
    set @all_atables = "";
    set @next_day = "";
    repeat
        set @next_day = date_format(date_add(@this_or_next_year_lastday, interval @day_num day),'%y%m%d');
        set @atable_name = concat('z',@next_day ,'a');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@atable_name)
            then
                set @all_atables=@atable_name;
                set @out=@range_day_num;
        end if;
        set @out=@out+1;
        set @day_num=@day_num+1;
        until @out > @range_day_num
    end repeat;
    
    repeat
        set @next_day = date_format(date_add(@this_or_next_year_lastday, interval @day_num day),'%y%m%d');
        set @atable_name = concat('z',@next_day ,'a');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@atable_name) && (@all_atables != @atable_name)
            then
                set @all_atables = concat_ws(',',@all_atables,@atable_name);
        end if;
        set @day_num=@day_num + 1;
        until @day_num > @range_day_num
    end repeat;

    
    set @day_num = 0;
    set @out = @day_num;
    set @all_btables = "";
    set @next_day = "";
    repeat
        set @next_day = date_format(date_add(@this_or_next_year_lastday, interval @day_num day),'%y%m%d');
        set @btable_name = concat('z',@next_day ,'b');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@btable_name)
            then
                set @all_btables=@btable_name;
                set @out=@range_day_num;
        end if;
        set @out=@out+1;
        set @day_num=@day_num+1;
        until @out > @range_day_num
    end repeat;
    
    repeat
        set @next_day = date_format(date_add(@this_or_next_year_lastday, interval @day_num day),'%y%m%d');
        set @btable_name = concat('z',@next_day ,'b');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@btable_name) && (@all_btables != @btable_name)
            then
                set @all_btables = concat_ws(',',@all_btables,@btable_name);
        end if;
        set @day_num=@day_num + 1;
        until @day_num > @range_day_num
    end repeat;

    set @atablename = concat('log_async_',date_format(@this_or_next_year,'%y'));
    set @full_aname = concat_ws('.',@databases,@atablename);
    set @btablename = concat('log_sync_',date_format(@this_or_next_year,'%y'));
    set @full_bname = concat_ws('.',@databases,@btablename);
 
    set @if_existe_drop_tablea = concat("
    DROP TABLE IF EXISTS ",@full_aname,";
    ");
    
    set @if_existe_drop_tableb = concat("
    DROP TABLE IF EXISTS ",@full_bname,";
    ");
    
    PREPARE drop_tablea FROM @if_existe_drop_tablea;
    PREPARE drop_tableb FROM @if_existe_drop_tableb;
    EXECUTE drop_tablea;
    EXECUTE drop_tableb;
    DEALLOCATE PREPARE drop_tablea;
    DEALLOCATE PREPARE drop_tableb;
    
    
    set @sql_add_converge_btable = concat("
    create table ",@full_bname,"(
        `id` BIGINT(20) NOT NULL COMMENT '通用日志表',
        `logId` INT(11) DEFAULT NULL COMMENT '对应表在配置库中',
        `para01` TEXT,
        `para02` TEXT,
        `para03` TEXT,
        `para04` TEXT,
        `para05` TEXT,
        `para06` TEXT,
        `para07` TEXT,
        `para08` TEXT,
        `para09` TEXT,
        `para10` TEXT,
        `para11` TEXT,
        `para12` TEXT,
        `para13` TEXT,
        `para14` TEXT,
        `para15` TEXT,
        `para16` TEXT,
        `para17` TEXT,
        `para18` TEXT,
        `para19` TEXT,
        `para20` TEXT,
        PRIMARY KEY (`id`),
        KEY `idx_logId` (`logId`)) engine=mrg_myisam union=() insert_method=last;
        ");
    set @sql_add_converge_atable =concat("
    create table ",@full_aname,"(
        `id` BIGINT(20) NOT NULL COMMENT '通用日志表',
        `logId` INT(11) DEFAULT NULL COMMENT '对应表在配置库中',
        `para01` TEXT,
        `para02` TEXT,
        `para03` TEXT,
        `para04` TEXT,
        `para05` TEXT,
        `para06` TEXT,
        `para07` TEXT,
        `para08` TEXT,
        `para09` TEXT,
        `para10` TEXT,
        `para11` TEXT,
        `para12` TEXT,
        `para13` TEXT,
        `para14` TEXT,
        `para15` TEXT,
        `para16` TEXT,
        `para17` TEXT,
        `para18` TEXT,
        `para19` TEXT,
        `para20` TEXT,
        PRIMARY KEY (`id`),
        KEY `idx_logId` (`logId`)) engine=mrg_myisam union=() insert_method=last;
    ");
        
    set @sql_alt_mrga_text = concat(
        "ALTER TABLE ",@full_aname," engine=mrg_myisam union=(",@all_atables,") insert_method=last;"
    );
    set @sql_alt_mrgb_text = concat(
        "ALTER TABLE ",@full_bname," engine=mrg_myisam union=(",@all_btables,") insert_method=last;"
    );
    
    PREPARE creat_tablea FROM @sql_add_converge_atable;
    PREPARE creat_tableb FROM @sql_add_converge_btable;
    EXECUTE creat_tablea;
    EXECUTE creat_tableb;
    DEALLOCATE PREPARE creat_tablea;
    DEALLOCATE PREPARE creat_tableb;
    
    PREPARE alt_mrg_a FROM @sql_alt_mrga_text;
    PREPARE alt_mrg_b FROM @sql_alt_mrgb_text;
    EXECUTE alt_mrg_a;
    EXECUTE alt_mrg_b;
    DEALLOCATE PREPARE alt_mrg_a;
    DEALLOCATE PREPARE alt_mrg_b;
END */$$
DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
