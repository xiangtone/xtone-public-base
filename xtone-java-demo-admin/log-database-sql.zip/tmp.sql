/*
SQLyog Community v11.1 (64 bit)
MySQL - 5.6.24-log : Database - log_general
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`log_general` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `log_general`;

/*Table structure for table `log_async_16` */

DROP TABLE IF EXISTS `log_async_16`;

CREATE TABLE `log_async_16` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MRG_MyISAM DEFAULT CHARSET=utf8 INSERT_METHOD=LAST UNION=(`z160114a`,`z160115a`,`z160116a`,`z160117a`,`z160118a`,`z160119a`,`z160120a`,`z160121a`,`z160122a`,`z160123a`,`z160124a`,`z160125a`,`z160126a`,`z160127a`,`z160128a`,`z160129a`,`z160130a`,`z160131a`,`z160201a`,`z160202a`,`z160203a`,`z160204a`,`z160205a`,`z160206a`,`z160207a`,`z160208a`,`z160209a`,`z160210a`,`z160211a`,`z160212a`,`z160213a`,`z160214a`,`z160215a`,`z160216a`,`z160217a`,`z160218a`,`z160219a`,`z160220a`,`z160221a`,`z160222a`,`z160223a`,`z160224a`,`z160225a`,`z160226a`,`z160227a`,`z160228a`,`z160229a`,`z160301a`,`z160302a`,`z160303a`,`z160304a`,`z160305a`,`z160306a`,`z160307a`,`z160308a`,`z160309a`,`z160310a`,`z160311a`,`z160312a`,`z160313a`,`z160314a`,`z160315a`,`z160316a`,`z160317a`,`z160318a`,`z160319a`,`z160320a`,`z160321a`,`z160322a`,`z160323a`,`z160324a`,`z160325a`,`z160326a`,`z160327a`,`z160328a`,`z160329a`,`z160330a`,`z160331a`,`z160401a`,`z160402a`,`z160403a`,`z160404a`,`z160405a`,`z160406a`,`z160407a`,`z160408a`,`z160409a`,`z160410a`,`z160411a`,`z160412a`,`z160413a`,`z160414a`,`z160415a`,`z160416a`,`z160417a`,`z160418a`,`z160419a`,`z160420a`,`z160421a`,`z160422a`,`z160423a`,`z160424a`,`z160425a`,`z160426a`,`z160427a`,`z160428a`,`z160429a`,`z160430a`,`z160501a`,`z160502a`,`z160503a`,`z160504a`,`z160505a`,`z160506a`,`z160507a`,`z160508a`,`z160509a`,`z160510a`,`z160511a`,`z160512a`,`z160513a`,`z160514a`,`z160515a`,`z160516a`,`z160517a`,`z160518a`,`z160519a`,`z160520a`,`z160521a`,`z160522a`,`z160523a`,`z160524a`,`z160525a`,`z160526a`,`z160527a`,`z160528a`,`z160529a`,`z160530a`,`z160531a`,`z160601a`,`z160602a`,`z160603a`,`z160604a`,`z160605a`,`z160606a`,`z160607a`,`z160608a`);

/*Table structure for table `log_async_1604` */

DROP TABLE IF EXISTS `log_async_1604`;

CREATE TABLE `log_async_1604` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MRG_MyISAM DEFAULT CHARSET=utf8 INSERT_METHOD=LAST UNION=(`z160331a`,`z160401a`,`z160402a`,`z160403a`,`z160404a`,`z160405a`,`z160406a`,`z160407a`,`z160408a`,`z160409a`,`z160410a`,`z160411a`,`z160412a`,`z160413a`,`z160414a`,`z160415a`,`z160416a`,`z160417a`,`z160418a`,`z160419a`,`z160420a`,`z160421a`,`z160422a`,`z160423a`,`z160424a`,`z160425a`,`z160426a`,`z160427a`,`z160428a`,`z160429a`,`z160430a`,`z160501a`);

/*Table structure for table `log_async_1605` */

DROP TABLE IF EXISTS `log_async_1605`;

CREATE TABLE `log_async_1605` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MRG_MyISAM DEFAULT CHARSET=utf8 INSERT_METHOD=LAST UNION=(`z160430a`,`z160501a`,`z160502a`,`z160503a`,`z160504a`,`z160505a`,`z160506a`,`z160507a`,`z160508a`,`z160509a`,`z160510a`,`z160511a`,`z160512a`,`z160513a`,`z160514a`,`z160515a`,`z160516a`,`z160517a`,`z160518a`,`z160519a`,`z160520a`,`z160521a`,`z160522a`,`z160523a`,`z160524a`,`z160525a`,`z160526a`,`z160527a`,`z160528a`,`z160529a`,`z160530a`,`z160531a`,`z160601a`);

/*Table structure for table `log_async_1606` */

DROP TABLE IF EXISTS `log_async_1606`;

CREATE TABLE `log_async_1606` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MRG_MyISAM DEFAULT CHARSET=utf8 INSERT_METHOD=LAST UNION=(`z160531a`,`z160601a`,`z160602a`,`z160603a`,`z160604a`,`z160605a`,`z160606a`,`z160607a`,`z160608a`);

/*Table structure for table `log_async_generals` */

DROP TABLE IF EXISTS `log_async_generals`;

CREATE TABLE `log_async_generals` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MRG_MyISAM DEFAULT CHARSET=utf8 INSERT_METHOD=LAST UNION=(`z160607a`,`z160608a`);

/*Table structure for table `log_async_last_hundred_days` */

DROP TABLE IF EXISTS `log_async_last_hundred_days`;

CREATE TABLE `log_async_last_hundred_days` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MRG_MyISAM DEFAULT CHARSET=utf8 UNION=(`z160229a`,`z160301a`,`z160302a`,`z160303a`,`z160304a`,`z160305a`,`z160306a`,`z160307a`,`z160308a`,`z160309a`,`z160310a`,`z160311a`,`z160312a`,`z160313a`,`z160314a`,`z160315a`,`z160316a`,`z160317a`,`z160318a`,`z160319a`,`z160320a`,`z160321a`,`z160322a`,`z160323a`,`z160324a`,`z160325a`,`z160326a`,`z160327a`,`z160328a`,`z160329a`,`z160330a`,`z160331a`,`z160401a`,`z160402a`,`z160403a`,`z160404a`,`z160405a`,`z160406a`,`z160407a`,`z160408a`,`z160409a`,`z160410a`,`z160411a`,`z160412a`,`z160413a`,`z160414a`,`z160415a`,`z160416a`,`z160417a`,`z160418a`,`z160419a`,`z160420a`,`z160421a`,`z160422a`,`z160423a`,`z160424a`,`z160425a`,`z160426a`,`z160427a`,`z160428a`,`z160429a`,`z160430a`,`z160501a`,`z160502a`,`z160503a`,`z160504a`,`z160505a`,`z160506a`,`z160507a`,`z160508a`,`z160509a`,`z160510a`,`z160511a`,`z160512a`,`z160513a`,`z160514a`,`z160515a`,`z160516a`,`z160517a`,`z160518a`,`z160519a`,`z160520a`,`z160521a`,`z160522a`,`z160523a`,`z160524a`,`z160525a`,`z160526a`,`z160527a`,`z160528a`,`z160529a`,`z160530a`,`z160531a`,`z160601a`,`z160602a`,`z160603a`,`z160604a`,`z160605a`,`z160606a`,`z160607a`);

/*Table structure for table `log_sync_16` */

DROP TABLE IF EXISTS `log_sync_16`;

CREATE TABLE `log_sync_16` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MRG_MyISAM DEFAULT CHARSET=utf8 INSERT_METHOD=LAST UNION=(`z160114b`,`z160115b`,`z160116b`,`z160117b`,`z160118b`,`z160119b`,`z160120b`,`z160121b`,`z160122b`,`z160123b`,`z160124b`,`z160125b`,`z160126b`,`z160127b`,`z160128b`,`z160129b`,`z160130b`,`z160131b`,`z160201b`,`z160202b`,`z160203b`,`z160204b`,`z160205b`,`z160206b`,`z160207b`,`z160208b`,`z160209b`,`z160210b`,`z160211b`,`z160212b`,`z160213b`,`z160214b`,`z160215b`,`z160216b`,`z160217b`,`z160218b`,`z160219b`,`z160220b`,`z160221b`,`z160222b`,`z160223b`,`z160224b`,`z160225b`,`z160226b`,`z160227b`,`z160228b`,`z160229b`,`z160301b`,`z160302b`,`z160303b`,`z160304b`,`z160305b`,`z160306b`,`z160307b`,`z160308b`,`z160309b`,`z160310b`,`z160311b`,`z160312b`,`z160313b`,`z160314b`,`z160315b`,`z160316b`,`z160317b`,`z160318b`,`z160319b`,`z160320b`,`z160321b`,`z160322b`,`z160323b`,`z160324b`,`z160325b`,`z160326b`,`z160327b`,`z160328b`,`z160329b`,`z160330b`,`z160331b`,`z160401b`,`z160402b`,`z160403b`,`z160404b`,`z160405b`,`z160406b`,`z160407b`,`z160408b`,`z160409b`,`z160410b`,`z160411b`,`z160412b`,`z160413b`,`z160414b`,`z160415b`,`z160416b`,`z160417b`,`z160418b`,`z160419b`,`z160420b`,`z160421b`,`z160422b`,`z160423b`,`z160424b`,`z160425b`,`z160426b`,`z160427b`,`z160428b`,`z160429b`,`z160430b`,`z160501b`,`z160502b`,`z160503b`,`z160504b`,`z160505b`,`z160506b`,`z160507b`,`z160508b`,`z160509b`,`z160510b`,`z160511b`,`z160512b`,`z160513b`,`z160514b`,`z160515b`,`z160516b`,`z160517b`,`z160518b`,`z160519b`,`z160520b`,`z160521b`,`z160522b`,`z160523b`,`z160524b`,`z160525b`,`z160526b`,`z160527b`,`z160528b`,`z160529b`,`z160530b`,`z160531b`,`z160601b`,`z160602b`,`z160603b`,`z160604b`,`z160605b`,`z160606b`,`z160607b`,`z160608b`);

/*Table structure for table `log_sync_1604` */

DROP TABLE IF EXISTS `log_sync_1604`;

CREATE TABLE `log_sync_1604` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MRG_MyISAM DEFAULT CHARSET=utf8 INSERT_METHOD=LAST UNION=(`z160331b`,`z160401b`,`z160402b`,`z160403b`,`z160404b`,`z160405b`,`z160406b`,`z160407b`,`z160408b`,`z160409b`,`z160410b`,`z160411b`,`z160412b`,`z160413b`,`z160414b`,`z160415b`,`z160416b`,`z160417b`,`z160418b`,`z160419b`,`z160420b`,`z160421b`,`z160422b`,`z160423b`,`z160424b`,`z160425b`,`z160426b`,`z160427b`,`z160428b`,`z160429b`,`z160430b`,`z160501b`);

/*Table structure for table `log_sync_1605` */

DROP TABLE IF EXISTS `log_sync_1605`;

CREATE TABLE `log_sync_1605` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MRG_MyISAM DEFAULT CHARSET=utf8 INSERT_METHOD=LAST UNION=(`z160430b`,`z160501b`,`z160502b`,`z160503b`,`z160504b`,`z160505b`,`z160506b`,`z160507b`,`z160508b`,`z160509b`,`z160510b`,`z160511b`,`z160512b`,`z160513b`,`z160514b`,`z160515b`,`z160516b`,`z160517b`,`z160518b`,`z160519b`,`z160520b`,`z160521b`,`z160522b`,`z160523b`,`z160524b`,`z160525b`,`z160526b`,`z160527b`,`z160528b`,`z160529b`,`z160530b`,`z160531b`,`z160601b`);

/*Table structure for table `log_sync_1606` */

DROP TABLE IF EXISTS `log_sync_1606`;

CREATE TABLE `log_sync_1606` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MRG_MyISAM DEFAULT CHARSET=utf8 INSERT_METHOD=LAST UNION=(`z160531b`,`z160601b`,`z160602b`,`z160603b`,`z160604b`,`z160605b`,`z160606b`,`z160607b`,`z160608b`);

/*Table structure for table `log_sync_generals` */

DROP TABLE IF EXISTS `log_sync_generals`;

CREATE TABLE `log_sync_generals` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MRG_MyISAM DEFAULT CHARSET=utf8 INSERT_METHOD=LAST UNION=(`z160607b`,`z160608b`);

/*Table structure for table `log_sync_last_hundred_days` */

DROP TABLE IF EXISTS `log_sync_last_hundred_days`;

CREATE TABLE `log_sync_last_hundred_days` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MRG_MyISAM DEFAULT CHARSET=utf8 UNION=(`z160529b`,`z160530b`,`z160531b`,`z160601b`,`z160602b`,`z160603b`,`z160604b`,`z160605b`,`z160606b`,`z160607b`);

/*Table structure for table `z160114a` */

DROP TABLE IF EXISTS `z160114a`;

CREATE TABLE `z160114a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160114b` */

DROP TABLE IF EXISTS `z160114b`;

CREATE TABLE `z160114b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160115a` */

DROP TABLE IF EXISTS `z160115a`;

CREATE TABLE `z160115a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160115b` */

DROP TABLE IF EXISTS `z160115b`;

CREATE TABLE `z160115b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160116a` */

DROP TABLE IF EXISTS `z160116a`;

CREATE TABLE `z160116a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160116b` */

DROP TABLE IF EXISTS `z160116b`;

CREATE TABLE `z160116b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160117a` */

DROP TABLE IF EXISTS `z160117a`;

CREATE TABLE `z160117a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160117b` */

DROP TABLE IF EXISTS `z160117b`;

CREATE TABLE `z160117b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160118a` */

DROP TABLE IF EXISTS `z160118a`;

CREATE TABLE `z160118a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160118b` */

DROP TABLE IF EXISTS `z160118b`;

CREATE TABLE `z160118b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160119a` */

DROP TABLE IF EXISTS `z160119a`;

CREATE TABLE `z160119a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160119b` */

DROP TABLE IF EXISTS `z160119b`;

CREATE TABLE `z160119b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160120a` */

DROP TABLE IF EXISTS `z160120a`;

CREATE TABLE `z160120a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160120b` */

DROP TABLE IF EXISTS `z160120b`;

CREATE TABLE `z160120b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160121a` */

DROP TABLE IF EXISTS `z160121a`;

CREATE TABLE `z160121a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160121b` */

DROP TABLE IF EXISTS `z160121b`;

CREATE TABLE `z160121b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160122a` */

DROP TABLE IF EXISTS `z160122a`;

CREATE TABLE `z160122a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160122b` */

DROP TABLE IF EXISTS `z160122b`;

CREATE TABLE `z160122b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160123a` */

DROP TABLE IF EXISTS `z160123a`;

CREATE TABLE `z160123a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160123b` */

DROP TABLE IF EXISTS `z160123b`;

CREATE TABLE `z160123b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160124a` */

DROP TABLE IF EXISTS `z160124a`;

CREATE TABLE `z160124a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160124b` */

DROP TABLE IF EXISTS `z160124b`;

CREATE TABLE `z160124b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160125a` */

DROP TABLE IF EXISTS `z160125a`;

CREATE TABLE `z160125a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160125b` */

DROP TABLE IF EXISTS `z160125b`;

CREATE TABLE `z160125b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160126a` */

DROP TABLE IF EXISTS `z160126a`;

CREATE TABLE `z160126a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160126b` */

DROP TABLE IF EXISTS `z160126b`;

CREATE TABLE `z160126b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160127a` */

DROP TABLE IF EXISTS `z160127a`;

CREATE TABLE `z160127a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160127b` */

DROP TABLE IF EXISTS `z160127b`;

CREATE TABLE `z160127b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160128a` */

DROP TABLE IF EXISTS `z160128a`;

CREATE TABLE `z160128a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160128b` */

DROP TABLE IF EXISTS `z160128b`;

CREATE TABLE `z160128b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160129a` */

DROP TABLE IF EXISTS `z160129a`;

CREATE TABLE `z160129a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160129b` */

DROP TABLE IF EXISTS `z160129b`;

CREATE TABLE `z160129b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160130a` */

DROP TABLE IF EXISTS `z160130a`;

CREATE TABLE `z160130a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160130b` */

DROP TABLE IF EXISTS `z160130b`;

CREATE TABLE `z160130b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160131a` */

DROP TABLE IF EXISTS `z160131a`;

CREATE TABLE `z160131a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160131b` */

DROP TABLE IF EXISTS `z160131b`;

CREATE TABLE `z160131b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160201a` */

DROP TABLE IF EXISTS `z160201a`;

CREATE TABLE `z160201a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160201b` */

DROP TABLE IF EXISTS `z160201b`;

CREATE TABLE `z160201b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160202a` */

DROP TABLE IF EXISTS `z160202a`;

CREATE TABLE `z160202a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160202b` */

DROP TABLE IF EXISTS `z160202b`;

CREATE TABLE `z160202b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160203a` */

DROP TABLE IF EXISTS `z160203a`;

CREATE TABLE `z160203a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160203b` */

DROP TABLE IF EXISTS `z160203b`;

CREATE TABLE `z160203b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160204a` */

DROP TABLE IF EXISTS `z160204a`;

CREATE TABLE `z160204a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160204b` */

DROP TABLE IF EXISTS `z160204b`;

CREATE TABLE `z160204b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160205a` */

DROP TABLE IF EXISTS `z160205a`;

CREATE TABLE `z160205a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160205b` */

DROP TABLE IF EXISTS `z160205b`;

CREATE TABLE `z160205b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160206a` */

DROP TABLE IF EXISTS `z160206a`;

CREATE TABLE `z160206a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160206b` */

DROP TABLE IF EXISTS `z160206b`;

CREATE TABLE `z160206b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160207a` */

DROP TABLE IF EXISTS `z160207a`;

CREATE TABLE `z160207a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160207b` */

DROP TABLE IF EXISTS `z160207b`;

CREATE TABLE `z160207b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160208a` */

DROP TABLE IF EXISTS `z160208a`;

CREATE TABLE `z160208a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160208b` */

DROP TABLE IF EXISTS `z160208b`;

CREATE TABLE `z160208b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160209a` */

DROP TABLE IF EXISTS `z160209a`;

CREATE TABLE `z160209a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160209b` */

DROP TABLE IF EXISTS `z160209b`;

CREATE TABLE `z160209b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160210a` */

DROP TABLE IF EXISTS `z160210a`;

CREATE TABLE `z160210a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160210b` */

DROP TABLE IF EXISTS `z160210b`;

CREATE TABLE `z160210b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160211a` */

DROP TABLE IF EXISTS `z160211a`;

CREATE TABLE `z160211a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160211b` */

DROP TABLE IF EXISTS `z160211b`;

CREATE TABLE `z160211b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160212a` */

DROP TABLE IF EXISTS `z160212a`;

CREATE TABLE `z160212a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160212b` */

DROP TABLE IF EXISTS `z160212b`;

CREATE TABLE `z160212b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160213a` */

DROP TABLE IF EXISTS `z160213a`;

CREATE TABLE `z160213a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160213b` */

DROP TABLE IF EXISTS `z160213b`;

CREATE TABLE `z160213b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160214a` */

DROP TABLE IF EXISTS `z160214a`;

CREATE TABLE `z160214a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160214b` */

DROP TABLE IF EXISTS `z160214b`;

CREATE TABLE `z160214b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160215a` */

DROP TABLE IF EXISTS `z160215a`;

CREATE TABLE `z160215a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160215b` */

DROP TABLE IF EXISTS `z160215b`;

CREATE TABLE `z160215b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160216a` */

DROP TABLE IF EXISTS `z160216a`;

CREATE TABLE `z160216a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160216b` */

DROP TABLE IF EXISTS `z160216b`;

CREATE TABLE `z160216b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160217a` */

DROP TABLE IF EXISTS `z160217a`;

CREATE TABLE `z160217a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160217b` */

DROP TABLE IF EXISTS `z160217b`;

CREATE TABLE `z160217b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160218a` */

DROP TABLE IF EXISTS `z160218a`;

CREATE TABLE `z160218a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160218b` */

DROP TABLE IF EXISTS `z160218b`;

CREATE TABLE `z160218b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160219a` */

DROP TABLE IF EXISTS `z160219a`;

CREATE TABLE `z160219a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160219b` */

DROP TABLE IF EXISTS `z160219b`;

CREATE TABLE `z160219b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160220a` */

DROP TABLE IF EXISTS `z160220a`;

CREATE TABLE `z160220a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160220b` */

DROP TABLE IF EXISTS `z160220b`;

CREATE TABLE `z160220b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160221a` */

DROP TABLE IF EXISTS `z160221a`;

CREATE TABLE `z160221a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160221b` */

DROP TABLE IF EXISTS `z160221b`;

CREATE TABLE `z160221b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160222a` */

DROP TABLE IF EXISTS `z160222a`;

CREATE TABLE `z160222a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160222b` */

DROP TABLE IF EXISTS `z160222b`;

CREATE TABLE `z160222b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160223a` */

DROP TABLE IF EXISTS `z160223a`;

CREATE TABLE `z160223a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160223b` */

DROP TABLE IF EXISTS `z160223b`;

CREATE TABLE `z160223b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160224a` */

DROP TABLE IF EXISTS `z160224a`;

CREATE TABLE `z160224a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160224b` */

DROP TABLE IF EXISTS `z160224b`;

CREATE TABLE `z160224b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160225a` */

DROP TABLE IF EXISTS `z160225a`;

CREATE TABLE `z160225a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160225b` */

DROP TABLE IF EXISTS `z160225b`;

CREATE TABLE `z160225b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160226a` */

DROP TABLE IF EXISTS `z160226a`;

CREATE TABLE `z160226a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160226b` */

DROP TABLE IF EXISTS `z160226b`;

CREATE TABLE `z160226b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160227a` */

DROP TABLE IF EXISTS `z160227a`;

CREATE TABLE `z160227a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160227b` */

DROP TABLE IF EXISTS `z160227b`;

CREATE TABLE `z160227b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160228a` */

DROP TABLE IF EXISTS `z160228a`;

CREATE TABLE `z160228a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160228b` */

DROP TABLE IF EXISTS `z160228b`;

CREATE TABLE `z160228b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160229a` */

DROP TABLE IF EXISTS `z160229a`;

CREATE TABLE `z160229a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160229b` */

DROP TABLE IF EXISTS `z160229b`;

CREATE TABLE `z160229b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160301a` */

DROP TABLE IF EXISTS `z160301a`;

CREATE TABLE `z160301a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160301b` */

DROP TABLE IF EXISTS `z160301b`;

CREATE TABLE `z160301b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160302a` */

DROP TABLE IF EXISTS `z160302a`;

CREATE TABLE `z160302a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160302b` */

DROP TABLE IF EXISTS `z160302b`;

CREATE TABLE `z160302b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160303a` */

DROP TABLE IF EXISTS `z160303a`;

CREATE TABLE `z160303a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160303b` */

DROP TABLE IF EXISTS `z160303b`;

CREATE TABLE `z160303b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160304a` */

DROP TABLE IF EXISTS `z160304a`;

CREATE TABLE `z160304a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160304b` */

DROP TABLE IF EXISTS `z160304b`;

CREATE TABLE `z160304b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160305a` */

DROP TABLE IF EXISTS `z160305a`;

CREATE TABLE `z160305a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160305b` */

DROP TABLE IF EXISTS `z160305b`;

CREATE TABLE `z160305b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160306a` */

DROP TABLE IF EXISTS `z160306a`;

CREATE TABLE `z160306a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160306b` */

DROP TABLE IF EXISTS `z160306b`;

CREATE TABLE `z160306b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160307a` */

DROP TABLE IF EXISTS `z160307a`;

CREATE TABLE `z160307a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160307b` */

DROP TABLE IF EXISTS `z160307b`;

CREATE TABLE `z160307b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160308a` */

DROP TABLE IF EXISTS `z160308a`;

CREATE TABLE `z160308a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160308b` */

DROP TABLE IF EXISTS `z160308b`;

CREATE TABLE `z160308b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160309a` */

DROP TABLE IF EXISTS `z160309a`;

CREATE TABLE `z160309a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160309b` */

DROP TABLE IF EXISTS `z160309b`;

CREATE TABLE `z160309b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160310a` */

DROP TABLE IF EXISTS `z160310a`;

CREATE TABLE `z160310a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160310b` */

DROP TABLE IF EXISTS `z160310b`;

CREATE TABLE `z160310b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160311a` */

DROP TABLE IF EXISTS `z160311a`;

CREATE TABLE `z160311a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160311b` */

DROP TABLE IF EXISTS `z160311b`;

CREATE TABLE `z160311b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160312a` */

DROP TABLE IF EXISTS `z160312a`;

CREATE TABLE `z160312a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160312b` */

DROP TABLE IF EXISTS `z160312b`;

CREATE TABLE `z160312b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160313a` */

DROP TABLE IF EXISTS `z160313a`;

CREATE TABLE `z160313a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160313b` */

DROP TABLE IF EXISTS `z160313b`;

CREATE TABLE `z160313b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160314a` */

DROP TABLE IF EXISTS `z160314a`;

CREATE TABLE `z160314a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160314b` */

DROP TABLE IF EXISTS `z160314b`;

CREATE TABLE `z160314b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160315a` */

DROP TABLE IF EXISTS `z160315a`;

CREATE TABLE `z160315a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160315b` */

DROP TABLE IF EXISTS `z160315b`;

CREATE TABLE `z160315b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160316a` */

DROP TABLE IF EXISTS `z160316a`;

CREATE TABLE `z160316a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160316b` */

DROP TABLE IF EXISTS `z160316b`;

CREATE TABLE `z160316b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160317a` */

DROP TABLE IF EXISTS `z160317a`;

CREATE TABLE `z160317a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160317b` */

DROP TABLE IF EXISTS `z160317b`;

CREATE TABLE `z160317b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160318a` */

DROP TABLE IF EXISTS `z160318a`;

CREATE TABLE `z160318a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160318b` */

DROP TABLE IF EXISTS `z160318b`;

CREATE TABLE `z160318b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160319a` */

DROP TABLE IF EXISTS `z160319a`;

CREATE TABLE `z160319a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160319b` */

DROP TABLE IF EXISTS `z160319b`;

CREATE TABLE `z160319b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160320a` */

DROP TABLE IF EXISTS `z160320a`;

CREATE TABLE `z160320a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160320b` */

DROP TABLE IF EXISTS `z160320b`;

CREATE TABLE `z160320b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160321a` */

DROP TABLE IF EXISTS `z160321a`;

CREATE TABLE `z160321a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160321b` */

DROP TABLE IF EXISTS `z160321b`;

CREATE TABLE `z160321b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160322a` */

DROP TABLE IF EXISTS `z160322a`;

CREATE TABLE `z160322a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160322b` */

DROP TABLE IF EXISTS `z160322b`;

CREATE TABLE `z160322b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160323a` */

DROP TABLE IF EXISTS `z160323a`;

CREATE TABLE `z160323a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160323b` */

DROP TABLE IF EXISTS `z160323b`;

CREATE TABLE `z160323b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160324a` */

DROP TABLE IF EXISTS `z160324a`;

CREATE TABLE `z160324a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160324b` */

DROP TABLE IF EXISTS `z160324b`;

CREATE TABLE `z160324b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160325a` */

DROP TABLE IF EXISTS `z160325a`;

CREATE TABLE `z160325a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160325b` */

DROP TABLE IF EXISTS `z160325b`;

CREATE TABLE `z160325b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160326a` */

DROP TABLE IF EXISTS `z160326a`;

CREATE TABLE `z160326a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160326b` */

DROP TABLE IF EXISTS `z160326b`;

CREATE TABLE `z160326b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160327a` */

DROP TABLE IF EXISTS `z160327a`;

CREATE TABLE `z160327a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160327b` */

DROP TABLE IF EXISTS `z160327b`;

CREATE TABLE `z160327b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160328a` */

DROP TABLE IF EXISTS `z160328a`;

CREATE TABLE `z160328a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160328b` */

DROP TABLE IF EXISTS `z160328b`;

CREATE TABLE `z160328b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160329a` */

DROP TABLE IF EXISTS `z160329a`;

CREATE TABLE `z160329a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160329b` */

DROP TABLE IF EXISTS `z160329b`;

CREATE TABLE `z160329b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160330a` */

DROP TABLE IF EXISTS `z160330a`;

CREATE TABLE `z160330a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160330b` */

DROP TABLE IF EXISTS `z160330b`;

CREATE TABLE `z160330b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160331a` */

DROP TABLE IF EXISTS `z160331a`;

CREATE TABLE `z160331a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160331b` */

DROP TABLE IF EXISTS `z160331b`;

CREATE TABLE `z160331b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160401a` */

DROP TABLE IF EXISTS `z160401a`;

CREATE TABLE `z160401a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160401b` */

DROP TABLE IF EXISTS `z160401b`;

CREATE TABLE `z160401b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160402a` */

DROP TABLE IF EXISTS `z160402a`;

CREATE TABLE `z160402a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160402b` */

DROP TABLE IF EXISTS `z160402b`;

CREATE TABLE `z160402b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160403a` */

DROP TABLE IF EXISTS `z160403a`;

CREATE TABLE `z160403a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160403b` */

DROP TABLE IF EXISTS `z160403b`;

CREATE TABLE `z160403b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160404a` */

DROP TABLE IF EXISTS `z160404a`;

CREATE TABLE `z160404a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160404b` */

DROP TABLE IF EXISTS `z160404b`;

CREATE TABLE `z160404b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160405a` */

DROP TABLE IF EXISTS `z160405a`;

CREATE TABLE `z160405a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160405b` */

DROP TABLE IF EXISTS `z160405b`;

CREATE TABLE `z160405b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160406a` */

DROP TABLE IF EXISTS `z160406a`;

CREATE TABLE `z160406a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160406b` */

DROP TABLE IF EXISTS `z160406b`;

CREATE TABLE `z160406b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160407a` */

DROP TABLE IF EXISTS `z160407a`;

CREATE TABLE `z160407a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160407b` */

DROP TABLE IF EXISTS `z160407b`;

CREATE TABLE `z160407b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160408a` */

DROP TABLE IF EXISTS `z160408a`;

CREATE TABLE `z160408a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160408b` */

DROP TABLE IF EXISTS `z160408b`;

CREATE TABLE `z160408b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160409a` */

DROP TABLE IF EXISTS `z160409a`;

CREATE TABLE `z160409a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160409b` */

DROP TABLE IF EXISTS `z160409b`;

CREATE TABLE `z160409b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160410a` */

DROP TABLE IF EXISTS `z160410a`;

CREATE TABLE `z160410a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160410b` */

DROP TABLE IF EXISTS `z160410b`;

CREATE TABLE `z160410b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160411a` */

DROP TABLE IF EXISTS `z160411a`;

CREATE TABLE `z160411a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160411b` */

DROP TABLE IF EXISTS `z160411b`;

CREATE TABLE `z160411b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160412a` */

DROP TABLE IF EXISTS `z160412a`;

CREATE TABLE `z160412a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160412b` */

DROP TABLE IF EXISTS `z160412b`;

CREATE TABLE `z160412b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160413a` */

DROP TABLE IF EXISTS `z160413a`;

CREATE TABLE `z160413a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160413b` */

DROP TABLE IF EXISTS `z160413b`;

CREATE TABLE `z160413b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160414a` */

DROP TABLE IF EXISTS `z160414a`;

CREATE TABLE `z160414a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160414b` */

DROP TABLE IF EXISTS `z160414b`;

CREATE TABLE `z160414b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160415a` */

DROP TABLE IF EXISTS `z160415a`;

CREATE TABLE `z160415a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160415b` */

DROP TABLE IF EXISTS `z160415b`;

CREATE TABLE `z160415b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160416a` */

DROP TABLE IF EXISTS `z160416a`;

CREATE TABLE `z160416a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160416b` */

DROP TABLE IF EXISTS `z160416b`;

CREATE TABLE `z160416b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160417a` */

DROP TABLE IF EXISTS `z160417a`;

CREATE TABLE `z160417a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160417b` */

DROP TABLE IF EXISTS `z160417b`;

CREATE TABLE `z160417b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160418a` */

DROP TABLE IF EXISTS `z160418a`;

CREATE TABLE `z160418a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160418b` */

DROP TABLE IF EXISTS `z160418b`;

CREATE TABLE `z160418b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160419a` */

DROP TABLE IF EXISTS `z160419a`;

CREATE TABLE `z160419a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160419b` */

DROP TABLE IF EXISTS `z160419b`;

CREATE TABLE `z160419b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160420a` */

DROP TABLE IF EXISTS `z160420a`;

CREATE TABLE `z160420a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160420b` */

DROP TABLE IF EXISTS `z160420b`;

CREATE TABLE `z160420b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160421a` */

DROP TABLE IF EXISTS `z160421a`;

CREATE TABLE `z160421a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160421b` */

DROP TABLE IF EXISTS `z160421b`;

CREATE TABLE `z160421b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160422a` */

DROP TABLE IF EXISTS `z160422a`;

CREATE TABLE `z160422a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160422b` */

DROP TABLE IF EXISTS `z160422b`;

CREATE TABLE `z160422b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160423a` */

DROP TABLE IF EXISTS `z160423a`;

CREATE TABLE `z160423a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160423b` */

DROP TABLE IF EXISTS `z160423b`;

CREATE TABLE `z160423b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160424a` */

DROP TABLE IF EXISTS `z160424a`;

CREATE TABLE `z160424a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160424b` */

DROP TABLE IF EXISTS `z160424b`;

CREATE TABLE `z160424b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160425a` */

DROP TABLE IF EXISTS `z160425a`;

CREATE TABLE `z160425a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160425b` */

DROP TABLE IF EXISTS `z160425b`;

CREATE TABLE `z160425b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160426a` */

DROP TABLE IF EXISTS `z160426a`;

CREATE TABLE `z160426a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160426b` */

DROP TABLE IF EXISTS `z160426b`;

CREATE TABLE `z160426b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160427a` */

DROP TABLE IF EXISTS `z160427a`;

CREATE TABLE `z160427a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160427b` */

DROP TABLE IF EXISTS `z160427b`;

CREATE TABLE `z160427b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160428a` */

DROP TABLE IF EXISTS `z160428a`;

CREATE TABLE `z160428a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160428b` */

DROP TABLE IF EXISTS `z160428b`;

CREATE TABLE `z160428b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160429a` */

DROP TABLE IF EXISTS `z160429a`;

CREATE TABLE `z160429a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160429b` */

DROP TABLE IF EXISTS `z160429b`;

CREATE TABLE `z160429b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160430a` */

DROP TABLE IF EXISTS `z160430a`;

CREATE TABLE `z160430a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160430b` */

DROP TABLE IF EXISTS `z160430b`;

CREATE TABLE `z160430b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160501a` */

DROP TABLE IF EXISTS `z160501a`;

CREATE TABLE `z160501a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160501b` */

DROP TABLE IF EXISTS `z160501b`;

CREATE TABLE `z160501b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160502a` */

DROP TABLE IF EXISTS `z160502a`;

CREATE TABLE `z160502a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160502b` */

DROP TABLE IF EXISTS `z160502b`;

CREATE TABLE `z160502b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160503a` */

DROP TABLE IF EXISTS `z160503a`;

CREATE TABLE `z160503a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160503b` */

DROP TABLE IF EXISTS `z160503b`;

CREATE TABLE `z160503b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160504a` */

DROP TABLE IF EXISTS `z160504a`;

CREATE TABLE `z160504a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160504b` */

DROP TABLE IF EXISTS `z160504b`;

CREATE TABLE `z160504b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160505a` */

DROP TABLE IF EXISTS `z160505a`;

CREATE TABLE `z160505a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160505b` */

DROP TABLE IF EXISTS `z160505b`;

CREATE TABLE `z160505b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160506a` */

DROP TABLE IF EXISTS `z160506a`;

CREATE TABLE `z160506a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160506b` */

DROP TABLE IF EXISTS `z160506b`;

CREATE TABLE `z160506b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160507a` */

DROP TABLE IF EXISTS `z160507a`;

CREATE TABLE `z160507a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160507b` */

DROP TABLE IF EXISTS `z160507b`;

CREATE TABLE `z160507b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160508a` */

DROP TABLE IF EXISTS `z160508a`;

CREATE TABLE `z160508a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160508b` */

DROP TABLE IF EXISTS `z160508b`;

CREATE TABLE `z160508b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160509a` */

DROP TABLE IF EXISTS `z160509a`;

CREATE TABLE `z160509a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160509b` */

DROP TABLE IF EXISTS `z160509b`;

CREATE TABLE `z160509b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160510a` */

DROP TABLE IF EXISTS `z160510a`;

CREATE TABLE `z160510a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160510b` */

DROP TABLE IF EXISTS `z160510b`;

CREATE TABLE `z160510b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160511a` */

DROP TABLE IF EXISTS `z160511a`;

CREATE TABLE `z160511a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160511b` */

DROP TABLE IF EXISTS `z160511b`;

CREATE TABLE `z160511b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160512a` */

DROP TABLE IF EXISTS `z160512a`;

CREATE TABLE `z160512a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160512b` */

DROP TABLE IF EXISTS `z160512b`;

CREATE TABLE `z160512b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160513a` */

DROP TABLE IF EXISTS `z160513a`;

CREATE TABLE `z160513a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160513b` */

DROP TABLE IF EXISTS `z160513b`;

CREATE TABLE `z160513b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160514a` */

DROP TABLE IF EXISTS `z160514a`;

CREATE TABLE `z160514a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160514b` */

DROP TABLE IF EXISTS `z160514b`;

CREATE TABLE `z160514b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160515a` */

DROP TABLE IF EXISTS `z160515a`;

CREATE TABLE `z160515a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160515b` */

DROP TABLE IF EXISTS `z160515b`;

CREATE TABLE `z160515b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160516a` */

DROP TABLE IF EXISTS `z160516a`;

CREATE TABLE `z160516a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160516b` */

DROP TABLE IF EXISTS `z160516b`;

CREATE TABLE `z160516b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160517a` */

DROP TABLE IF EXISTS `z160517a`;

CREATE TABLE `z160517a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160517b` */

DROP TABLE IF EXISTS `z160517b`;

CREATE TABLE `z160517b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160518a` */

DROP TABLE IF EXISTS `z160518a`;

CREATE TABLE `z160518a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160518b` */

DROP TABLE IF EXISTS `z160518b`;

CREATE TABLE `z160518b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160519a` */

DROP TABLE IF EXISTS `z160519a`;

CREATE TABLE `z160519a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160519b` */

DROP TABLE IF EXISTS `z160519b`;

CREATE TABLE `z160519b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160520a` */

DROP TABLE IF EXISTS `z160520a`;

CREATE TABLE `z160520a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160520b` */

DROP TABLE IF EXISTS `z160520b`;

CREATE TABLE `z160520b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160521a` */

DROP TABLE IF EXISTS `z160521a`;

CREATE TABLE `z160521a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160521b` */

DROP TABLE IF EXISTS `z160521b`;

CREATE TABLE `z160521b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160522a` */

DROP TABLE IF EXISTS `z160522a`;

CREATE TABLE `z160522a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160522b` */

DROP TABLE IF EXISTS `z160522b`;

CREATE TABLE `z160522b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160523a` */

DROP TABLE IF EXISTS `z160523a`;

CREATE TABLE `z160523a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160523b` */

DROP TABLE IF EXISTS `z160523b`;

CREATE TABLE `z160523b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160524a` */

DROP TABLE IF EXISTS `z160524a`;

CREATE TABLE `z160524a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160524b` */

DROP TABLE IF EXISTS `z160524b`;

CREATE TABLE `z160524b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160525a` */

DROP TABLE IF EXISTS `z160525a`;

CREATE TABLE `z160525a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160525b` */

DROP TABLE IF EXISTS `z160525b`;

CREATE TABLE `z160525b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160526a` */

DROP TABLE IF EXISTS `z160526a`;

CREATE TABLE `z160526a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160526b` */

DROP TABLE IF EXISTS `z160526b`;

CREATE TABLE `z160526b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160527a` */

DROP TABLE IF EXISTS `z160527a`;

CREATE TABLE `z160527a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160527b` */

DROP TABLE IF EXISTS `z160527b`;

CREATE TABLE `z160527b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160528a` */

DROP TABLE IF EXISTS `z160528a`;

CREATE TABLE `z160528a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160528b` */

DROP TABLE IF EXISTS `z160528b`;

CREATE TABLE `z160528b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160529a` */

DROP TABLE IF EXISTS `z160529a`;

CREATE TABLE `z160529a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160529b` */

DROP TABLE IF EXISTS `z160529b`;

CREATE TABLE `z160529b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160530a` */

DROP TABLE IF EXISTS `z160530a`;

CREATE TABLE `z160530a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160530b` */

DROP TABLE IF EXISTS `z160530b`;

CREATE TABLE `z160530b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160531a` */

DROP TABLE IF EXISTS `z160531a`;

CREATE TABLE `z160531a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160531b` */

DROP TABLE IF EXISTS `z160531b`;

CREATE TABLE `z160531b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160601a` */

DROP TABLE IF EXISTS `z160601a`;

CREATE TABLE `z160601a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160601b` */

DROP TABLE IF EXISTS `z160601b`;

CREATE TABLE `z160601b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160602a` */

DROP TABLE IF EXISTS `z160602a`;

CREATE TABLE `z160602a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160602b` */

DROP TABLE IF EXISTS `z160602b`;

CREATE TABLE `z160602b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160603a` */

DROP TABLE IF EXISTS `z160603a`;

CREATE TABLE `z160603a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160603b` */

DROP TABLE IF EXISTS `z160603b`;

CREATE TABLE `z160603b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160604a` */

DROP TABLE IF EXISTS `z160604a`;

CREATE TABLE `z160604a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160604b` */

DROP TABLE IF EXISTS `z160604b`;

CREATE TABLE `z160604b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160605a` */

DROP TABLE IF EXISTS `z160605a`;

CREATE TABLE `z160605a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160605b` */

DROP TABLE IF EXISTS `z160605b`;

CREATE TABLE `z160605b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160606a` */

DROP TABLE IF EXISTS `z160606a`;

CREATE TABLE `z160606a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160606b` */

DROP TABLE IF EXISTS `z160606b`;

CREATE TABLE `z160606b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160607a` */

DROP TABLE IF EXISTS `z160607a`;

CREATE TABLE `z160607a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160607b` */

DROP TABLE IF EXISTS `z160607b`;

CREATE TABLE `z160607b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160608a` */

DROP TABLE IF EXISTS `z160608a`;

CREATE TABLE `z160608a` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `z160608b` */

DROP TABLE IF EXISTS `z160608b`;

CREATE TABLE `z160608b` (
  `id` bigint(20) NOT NULL COMMENT '通用日志表',
  `logId` int(11) DEFAULT NULL COMMENT '对应表在配置库中',
  `para01` text,
  `para02` text,
  `para03` text,
  `para04` text,
  `para05` text,
  `para06` text,
  `para07` text,
  `para08` text,
  `para09` text,
  `para10` text,
  `para11` text,
  `para12` text,
  `para13` text,
  `para14` text,
  `para15` text,
  `para16` text,
  `para17` text,
  `para18` text,
  `para19` text,
  `para20` text,
  PRIMARY KEY (`id`),
  KEY `idx_logId` (`logId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!50106 set global event_scheduler = 1*/;

/* Event structure for event `run_add_converge_100day_table` */

/*!50106 DROP EVENT IF EXISTS `run_add_converge_100day_table`*/;

DELIMITER $$

/*!50106 CREATE DEFINER=`root`@`%` EVENT `run_add_converge_100day_table` ON SCHEDULE EVERY 1 DAY STARTS '2016-04-15 00:05:00' ON COMPLETION NOT PRESERVE ENABLE DO call log_general.converge_100day_table() */$$
DELIMITER ;

/* Event structure for event `run_add_converge_month_table` */

/*!50106 DROP EVENT IF EXISTS `run_add_converge_month_table`*/;

DELIMITER $$

/*!50106 CREATE DEFINER=`root`@`%` EVENT `run_add_converge_month_table` ON SCHEDULE EVERY 1 DAY STARTS '2016-04-15 00:07:00' ON COMPLETION NOT PRESERVE ENABLE DO call log_general.converge_month_table() */$$
DELIMITER ;

/* Event structure for event `run_add_converge_year_table` */

/*!50106 DROP EVENT IF EXISTS `run_add_converge_year_table`*/;

DELIMITER $$

/*!50106 CREATE DEFINER=`root`@`%` EVENT `run_add_converge_year_table` ON SCHEDULE EVERY 1 DAY STARTS '2016-04-15 00:09:00' ON COMPLETION NOT PRESERVE ENABLE DO call log_general.converge_year_table() */$$
DELIMITER ;

/* Event structure for event `run_add_table` */

/*!50106 DROP EVENT IF EXISTS `run_add_table`*/;

DELIMITER $$

/*!50106 CREATE DEFINER=`root`@`%` EVENT `run_add_table` ON SCHEDULE EVERY 1 DAY STARTS '2016-01-16 00:00:00' ON COMPLETION NOT PRESERVE ENABLE DO call add_table() */$$
DELIMITER ;

/* Procedure structure for procedure `add_table` */

/*!50003 DROP PROCEDURE IF EXISTS  `add_table` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`%` PROCEDURE `add_table`()
BEGIN
    set @today = date_format(date(now()),'%y%m%d');
    set @yesterday = date_format(date_add(now(), interval -1 day),'%y%m%d');
    set @tb_namea = concat('z',@today,'a');
    set @old_tb_namea = concat('z',@yesterday,'a');
    set @old_tb_nameb = concat('z',@yesterday,'b');
    set @tb_nameb = concat('z',@today,'b'); 
    DROP TABLE IF EXISTS log_general.log_async_generals;
    DROP TABLE IF EXISTS log_general.log_sync_generals;
    
    create table log_general.log_sync_generals(
        `id` BIGINT(20) NOT NULL COMMENT '通用日志表',
        `logId` INT(11) DEFAULT NULL COMMENT '对应表在配置库中',
        `para01` TEXT,
        `para02` TEXT,
        `para03` TEXT,
        `para04` TEXT,
        `para05` TEXT,
        `para06` TEXT,
        `para07` TEXT,
        `para08` TEXT,
        `para09` TEXT,
        `para10` TEXT,
        `para11` TEXT,
        `para12` TEXT,
        `para13` TEXT,
        `para14` TEXT,
        `para15` TEXT,
        `para16` TEXT,
        `para17` TEXT,
        `para18` TEXT,
        `para19` TEXT,
        `para20` TEXT,
        PRIMARY KEY (`id`),
        KEY `idx_logId` (`logId`)) engine=mrg_myisam union=() insert_method=last;
    create table log_general.log_async_generals(
        `id` BIGINT(20) NOT NULL COMMENT '通用日志表',
        `logId` INT(11) DEFAULT NULL COMMENT '对应表在配置库中',
        `para01` TEXT,
        `para02` TEXT,
        `para03` TEXT,
        `para04` TEXT,
        `para05` TEXT,
        `para06` TEXT,
        `para07` TEXT,
        `para08` TEXT,
        `para09` TEXT,
        `para10` TEXT,
        `para11` TEXT,
        `para12` TEXT,
        `para13` TEXT,
        `para14` TEXT,
        `para15` TEXT,
        `para16` TEXT,
        `para17` TEXT,
        `para18` TEXT,
        `para19` TEXT,
        `para20` TEXT,
        PRIMARY KEY (`id`),
        KEY `idx_logId` (`logId`)) engine=mrg_myisam union=() insert_method=last;
        
        
    set @sql_add_tablea_text = concat(
        "CREATE TABLE ",@tb_namea," (
            `id` BIGINT(20) NOT NULL COMMENT '通用日志表',
            `logId` INT(11) DEFAULT NULL COMMENT '对应表在配置库中',
            `para01` TEXT,
            `para02` TEXT,
            `para03` TEXT,
            `para04` TEXT,
            `para05` TEXT,
            `para06` TEXT,
            `para07` TEXT,
            `para08` TEXT,
            `para09` TEXT,
            `para10` TEXT,
            `para11` TEXT,
            `para12` TEXT,
            `para13` TEXT,
            `para14` TEXT,
            `para15` TEXT,
            `para16` TEXT,
            `para17` TEXT,
            `para18` TEXT,
            `para19` TEXT,
            `para20` TEXT,
            PRIMARY KEY (`id`),
            KEY `idx_logId` (`logId`)
        )
        ENGINE=MYISAM DEFAULT CHARSET=utf8;"
    );
    set @sql_add_tableb_text = concat(
        "CREATE TABLE ",@tb_nameb," (
            `id` BIGINT(20) NOT NULL COMMENT '通用日志表',
            `logId` INT(11) DEFAULT NULL COMMENT '对应表在配置库中',
            `para01` TEXT,
            `para02` TEXT,
            `para03` TEXT,
            `para04` TEXT,
            `para05` TEXT,
            `para06` TEXT,
            `para07` TEXT,
            `para08` TEXT,
            `para09` TEXT,
            `para10` TEXT,
            `para11` TEXT,
            `para12` TEXT,
            `para13` TEXT,
            `para14` TEXT,
            `para15` TEXT,
            `para16` TEXT,
            `para17` TEXT,
            `para18` TEXT,
            `para19` TEXT,
            `para20` TEXT,
            PRIMARY KEY (`id`),
            KEY `idx_logId` (`logId`)
        )
        ENGINE=MYISAM DEFAULT CHARSET=utf8;"
    );
    set @sql_alt_mrga_text = concat(
        "ALTER TABLE log_async_generals engine=mrg_myisam union=(",@old_tb_namea,",",@tb_namea,") insert_method=last;"
    );
    set @sql_alt_mrgb_text = concat(
        "ALTER TABLE log_sync_generals engine=mrg_myisam union=(",@old_tb_nameb,",",@tb_nameb,") insert_method=last;"
    );
    
    PREPARE statement_namea FROM @sql_add_tablea_text;
    PREPARE statement_nameb FROM @sql_add_tableb_text;
    EXECUTE statement_namea;
    EXECUTE statement_nameb;
    DEALLOCATE PREPARE statement_namea;
    DEALLOCATE PREPARE statement_nameb;
    
    
    PREPARE alt_mrg_a FROM @sql_alt_mrga_text;
    PREPARE alt_mrg_b FROM @sql_alt_mrgb_text;
    EXECUTE alt_mrg_a;
    EXECUTE alt_mrg_b;
    DEALLOCATE PREPARE alt_mrg_a;
    DEALLOCATE PREPARE alt_mrg_b;
END */$$
DELIMITER ;

/* Procedure structure for procedure `converge_100day_table` */

/*!50003 DROP PROCEDURE IF EXISTS  `converge_100day_table` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`%` PROCEDURE `converge_100day_table`()
BEGIN
    set @databases = 'log_general';
    set @day_num=1;
    set @range_day_num=100;
    set @atable_name='';
    set @all_atables='';
    set @out=@day_num;
    repeat
        set @next_day = date_format(date_add(now(), interval -@day_num day),'%y%m%d');
        set @atable_name = concat('z',@next_day ,'a');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@atable_name)
            then
                set @all_atables=@atable_name;
                set @out=@range_day_num;
        end if;
        set @out=@out+1;
        set @day_num=@day_num+1;
        until @out > @range_day_num
    end repeat;
    
    repeat
        set @next_day = date_format(date_add(now(), interval -@day_num day),'%y%m%d');
        set @atable_name = concat('z',@next_day ,'a');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@atable_name) && (@all_atables != @atable_name)
            then
                set @all_atables = concat_ws(',',@atable_name,@all_atables);
        end if;
        set @day_num=@day_num + 1;
        until @day_num > @range_day_num
    end repeat;
    
    set @day_num=1;
    set @range_day_num=10;
    set @btable_name='';
    set @all_btables='';
    set @out=@day_num;
    repeat
        set @next_day = date_format(date_add(now(), interval -@day_num day),'%y%m%d');
        set @btable_name = concat('z',@next_day ,'b');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@btable_name)
            then
                set @all_btables=@btable_name;
                set @out=@range_day_num;
        end if;
        set @out=@out+1;
        set @day_num=@day_num+1;
        until @out > @range_day_num
    end repeat;
    
    repeat
        set @next_day = date_format(date_add(now(), interval -@day_num day),'%y%m%d');
        set @btable_name = concat('z',@next_day ,'b');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@btable_name) && (@all_btables != @btable_name)
            then
                set @all_btables = concat_ws(',',@btable_name,@all_btables);
        end if;
        set @day_num=@day_num + 1;
        until @day_num > @range_day_num
    end repeat;    
    
    DROP TABLE IF EXISTS log_general.log_async_last_hundred_days;
    DROP TABLE IF EXISTS log_general.log_sync_last_hundred_days;
    
    create table log_general.log_sync_last_hundred_days(
        `id` BIGINT(20) NOT NULL COMMENT '通用日志表',
        `logId` INT(11) DEFAULT NULL COMMENT '对应表在配置库中',
        `para01` TEXT,
        `para02` TEXT,
        `para03` TEXT,
        `para04` TEXT,
        `para05` TEXT,
        `para06` TEXT,
        `para07` TEXT,
        `para08` TEXT,
        `para09` TEXT,
        `para10` TEXT,
        `para11` TEXT,
        `para12` TEXT,
        `para13` TEXT,
        `para14` TEXT,
        `para15` TEXT,
        `para16` TEXT,
        `para17` TEXT,
        `para18` TEXT,
        `para19` TEXT,
        `para20` TEXT,
        PRIMARY KEY (`id`),
        KEY `idx_logId` (`logId`)) engine=mrg_myisam union=() insert_method=last;
    create table log_general.log_async_last_hundred_days(
        `id` BIGINT(20) NOT NULL COMMENT '通用日志表',
        `logId` INT(11) DEFAULT NULL COMMENT '对应表在配置库中',
        `para01` TEXT,
        `para02` TEXT,
        `para03` TEXT,
        `para04` TEXT,
        `para05` TEXT,
        `para06` TEXT,
        `para07` TEXT,
        `para08` TEXT,
        `para09` TEXT,
        `para10` TEXT,
        `para11` TEXT,
        `para12` TEXT,
        `para13` TEXT,
        `para14` TEXT,
        `para15` TEXT,
        `para16` TEXT,
        `para17` TEXT,
        `para18` TEXT,
        `para19` TEXT,
        `para20` TEXT,
        PRIMARY KEY (`id`),
        KEY `idx_logId` (`logId`)) engine=mrg_myisam union=() insert_method=last;
    
    set @sql_alt_mrga_hundred_days = concat(
        "ALTER TABLE log_async_last_hundred_days engine=mrg_myisam union=(",@all_atables,") insert_method=no;"
    );
    set @sql_alt_mrgb_hundred_days = concat(
        "ALTER TABLE log_sync_last_hundred_days engine=mrg_myisam union=(",@all_btables,") insert_method=no;"
    );

    PREPARE alt_mrg_a FROM @sql_alt_mrga_hundred_days;
    PREPARE alt_mrg_b FROM @sql_alt_mrgb_hundred_days;
    EXECUTE alt_mrg_a;
    EXECUTE alt_mrg_b;
    DEALLOCATE PREPARE alt_mrg_a;
    DEALLOCATE PREPARE alt_mrg_b;
    
END */$$
DELIMITER ;

/* Procedure structure for procedure `converge_month_table` */

/*!50003 DROP PROCEDURE IF EXISTS  `converge_month_table` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`%` PROCEDURE `converge_month_table`()
BEGIN
    
    set @databases = 'log_general';
    set @today = date_format(now(),'%y%m%d');
    set @last_or_this_month = '';
    if  day(@today) = 1
    then
        set @last_or_this_month = date_format(date_add(@today, interval -1 month),'%y%m%d');
    else
        set @last_or_this_month = date_format(date_add(@today, interval 0 month),'%y%m%d');
    end if;
    set @last_last_or_this_month = date_format(date_add(@last_or_this_month, interval -1 month),'%y%m%d');
    set @last_or_this_month_lastday = date_format(last_day(@last_last_or_this_month),'%y%m%d');
    set @this_or_next_month_firstday = date_format(date_add(last_day(@last_or_this_month),interval 1 day),'%y%m%d');
    set @range_day_num = to_days(@this_or_next_month_firstday) - to_days(@last_or_this_month_lastday);
    
    set @day_num = 0;
    set @out = @day_num;
    set @all_atables = "";
    set @next_day = "";
    repeat
        set @next_day = date_format(date_add(@last_or_this_month_lastday, interval @day_num day),'%y%m%d');
        set @atable_name = concat('z',@next_day ,'a');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@atable_name)
            then
                set @all_atables=@atable_name;
                set @out=@range_day_num;
        end if;
        set @out=@out+1;
        set @day_num=@day_num+1;
        until @out > @range_day_num
    end repeat;
    
    repeat
        set @next_day = date_format(date_add(@last_or_this_month_lastday, interval @day_num day),'%y%m%d');
        set @atable_name = concat('z',@next_day ,'a');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@atable_name) && (@all_atables != @atable_name)
            then
                set @all_atables = concat_ws(',',@all_atables,@atable_name);
        end if;
        set @day_num=@day_num + 1;
        until @day_num > @range_day_num
    end repeat;

    
    set @day_num = 0;
    set @out = @day_num;
    set @all_btables = "";
    set @next_day = "";
    repeat
        set @next_day = date_format(date_add(@last_or_this_month_lastday, interval @day_num day),'%y%m%d');
        set @btable_name = concat('z',@next_day ,'b');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@btable_name)
            then
                set @all_btables=@btable_name;
                set @out=@range_day_num;
        end if;
        set @out=@out+1;
        set @day_num=@day_num+1;
        until @out > @range_day_num
    end repeat;
    
    repeat
        set @next_day = date_format(date_add(@last_or_this_month_lastday, interval @day_num day),'%y%m%d');
        set @btable_name = concat('z',@next_day ,'b');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@btable_name) && (@all_btables != @btable_name)
            then
                set @all_btables = concat_ws(',',@all_btables,@btable_name);
        end if;
        set @day_num=@day_num + 1;
        until @day_num > @range_day_num
    end repeat;

    set @atablename = concat('log_async_',date_format(@last_or_this_month,'%y%m'));
    set @full_aname = concat_ws('.',@databases,@atablename);
    set @btablename = concat('log_sync_',date_format(@last_or_this_month,'%y%m'));
    set @full_bname = concat_ws('.',@databases,@btablename);
 
    set @if_existe_drop_tablea = concat("
    DROP TABLE IF EXISTS ",@full_aname,";
    ");
    
    set @if_existe_drop_tableb = concat("
    DROP TABLE IF EXISTS ",@full_bname,";
    ");
    
    PREPARE drop_tablea FROM @if_existe_drop_tablea;
    PREPARE drop_tableb FROM @if_existe_drop_tableb;
    EXECUTE drop_tablea;
    EXECUTE drop_tableb;
    DEALLOCATE PREPARE drop_tablea;
    DEALLOCATE PREPARE drop_tableb;
    
    
    set @sql_add_converge_btable = concat("
    create table ",@full_bname,"(
        `id` BIGINT(20) NOT NULL COMMENT '通用日志表',
        `logId` INT(11) DEFAULT NULL COMMENT '对应表在配置库中',
        `para01` TEXT,
        `para02` TEXT,
        `para03` TEXT,
        `para04` TEXT,
        `para05` TEXT,
        `para06` TEXT,
        `para07` TEXT,
        `para08` TEXT,
        `para09` TEXT,
        `para10` TEXT,
        `para11` TEXT,
        `para12` TEXT,
        `para13` TEXT,
        `para14` TEXT,
        `para15` TEXT,
        `para16` TEXT,
        `para17` TEXT,
        `para18` TEXT,
        `para19` TEXT,
        `para20` TEXT,
        PRIMARY KEY (`id`),
        KEY `idx_logId` (`logId`)) engine=mrg_myisam union=() insert_method=last;
        ");
    set @sql_add_converge_atable =concat("
    create table ",@full_aname,"(
        `id` BIGINT(20) NOT NULL COMMENT '通用日志表',
        `logId` INT(11) DEFAULT NULL COMMENT '对应表在配置库中',
        `para01` TEXT,
        `para02` TEXT,
        `para03` TEXT,
        `para04` TEXT,
        `para05` TEXT,
        `para06` TEXT,
        `para07` TEXT,
        `para08` TEXT,
        `para09` TEXT,
        `para10` TEXT,
        `para11` TEXT,
        `para12` TEXT,
        `para13` TEXT,
        `para14` TEXT,
        `para15` TEXT,
        `para16` TEXT,
        `para17` TEXT,
        `para18` TEXT,
        `para19` TEXT,
        `para20` TEXT,
        PRIMARY KEY (`id`),
        KEY `idx_logId` (`logId`)) engine=mrg_myisam union=() insert_method=last;
    ");
        
    set @sql_alt_mrga_text = concat(
        "ALTER TABLE ",@atablename," engine=mrg_myisam union=(",@all_atables,") insert_method=last;"
    );
    set @sql_alt_mrgb_text = concat(
        "ALTER TABLE ",@btablename," engine=mrg_myisam union=(",@all_btables,") insert_method=last;"
    );
    
    PREPARE creat_tablea FROM @sql_add_converge_atable;
    PREPARE creat_tableb FROM @sql_add_converge_btable;
    EXECUTE creat_tablea;
    EXECUTE creat_tableb;
    DEALLOCATE PREPARE creat_tablea;
    DEALLOCATE PREPARE creat_tableb;
    
    PREPARE alt_mrg_a FROM @sql_alt_mrga_text;
    PREPARE alt_mrg_b FROM @sql_alt_mrgb_text;
    EXECUTE alt_mrg_a;
    EXECUTE alt_mrg_b;
    DEALLOCATE PREPARE alt_mrg_a;
    DEALLOCATE PREPARE alt_mrg_b;
END */$$
DELIMITER ;

/* Procedure structure for procedure `converge_year_table` */

/*!50003 DROP PROCEDURE IF EXISTS  `converge_year_table` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`%` PROCEDURE `converge_year_table`()
BEGIN
    
    set @databases = 'log_general';
    set @today = date_format(now(),'%y%m%d');
    set @this_or_next_year = '';
    if date_format(@today,'%m%d') = '0101'
    then
        set @this_or_next_year = date_format(date_add(@today, interval -1 year),'%y%m%d');
    else
        set @this_or_next_year = date_format(date_add(@today, interval 0 year),'%y%m%d');
    end if;
    
    set @last_this_or_next_year = date_format(date_add(@this_or_next_year, interval -1 year),'%y%m%d');
    set @this_or_next_year_lastday = concat(date_format(@last_this_or_next_year,'%y'),'1231');
    
    set @this_or_next_year_firstday = concat(date_format(date_add(@this_or_next_year,interval 1 year),'%y'),'0101');


    set @range_day_num = to_days(@this_or_next_year_firstday) - to_days(@this_or_next_year_lastday);
    
    
    
    set @day_num = 0;
    set @out = @day_num;
    set @all_atables = "";
    set @next_day = "";
    repeat
        set @next_day = date_format(date_add(@this_or_next_year_lastday, interval @day_num day),'%y%m%d');
        set @atable_name = concat('z',@next_day ,'a');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@atable_name)
            then
                set @all_atables=@atable_name;
                set @out=@range_day_num;
        end if;
        set @out=@out+1;
        set @day_num=@day_num+1;
        until @out > @range_day_num
    end repeat;
    
    repeat
        set @next_day = date_format(date_add(@this_or_next_year_lastday, interval @day_num day),'%y%m%d');
        set @atable_name = concat('z',@next_day ,'a');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@atable_name) && (@all_atables != @atable_name)
            then
                set @all_atables = concat_ws(',',@all_atables,@atable_name);
        end if;
        set @day_num=@day_num + 1;
        until @day_num > @range_day_num
    end repeat;

    
    set @day_num = 0;
    set @out = @day_num;
    set @all_btables = "";
    set @next_day = "";
    repeat
        set @next_day = date_format(date_add(@this_or_next_year_lastday, interval @day_num day),'%y%m%d');
        set @btable_name = concat('z',@next_day ,'b');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@btable_name)
            then
                set @all_btables=@btable_name;
                set @out=@range_day_num;
        end if;
        set @out=@out+1;
        set @day_num=@day_num+1;
        until @out > @range_day_num
    end repeat;
    
    repeat
        set @next_day = date_format(date_add(@this_or_next_year_lastday, interval @day_num day),'%y%m%d');
        set @btable_name = concat('z',@next_day ,'b');
        if exists(select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA=@databases and TABLE_NAME=@btable_name) && (@all_btables != @btable_name)
            then
                set @all_btables = concat_ws(',',@all_btables,@btable_name);
        end if;
        set @day_num=@day_num + 1;
        until @day_num > @range_day_num
    end repeat;

    set @atablename = concat('log_async_',date_format(@this_or_next_year,'%y'));
    set @full_aname = concat_ws('.',@databases,@atablename);
    set @btablename = concat('log_sync_',date_format(@this_or_next_year,'%y'));
    set @full_bname = concat_ws('.',@databases,@btablename);
 
    set @if_existe_drop_tablea = concat("
    DROP TABLE IF EXISTS ",@full_aname,";
    ");
    
    set @if_existe_drop_tableb = concat("
    DROP TABLE IF EXISTS ",@full_bname,";
    ");
    
    PREPARE drop_tablea FROM @if_existe_drop_tablea;
    PREPARE drop_tableb FROM @if_existe_drop_tableb;
    EXECUTE drop_tablea;
    EXECUTE drop_tableb;
    DEALLOCATE PREPARE drop_tablea;
    DEALLOCATE PREPARE drop_tableb;
    
    
    set @sql_add_converge_btable = concat("
    create table ",@full_bname,"(
        `id` BIGINT(20) NOT NULL COMMENT '通用日志表',
        `logId` INT(11) DEFAULT NULL COMMENT '对应表在配置库中',
        `para01` TEXT,
        `para02` TEXT,
        `para03` TEXT,
        `para04` TEXT,
        `para05` TEXT,
        `para06` TEXT,
        `para07` TEXT,
        `para08` TEXT,
        `para09` TEXT,
        `para10` TEXT,
        `para11` TEXT,
        `para12` TEXT,
        `para13` TEXT,
        `para14` TEXT,
        `para15` TEXT,
        `para16` TEXT,
        `para17` TEXT,
        `para18` TEXT,
        `para19` TEXT,
        `para20` TEXT,
        PRIMARY KEY (`id`),
        KEY `idx_logId` (`logId`)) engine=mrg_myisam union=() insert_method=last;
        ");
    set @sql_add_converge_atable =concat("
    create table ",@full_aname,"(
        `id` BIGINT(20) NOT NULL COMMENT '通用日志表',
        `logId` INT(11) DEFAULT NULL COMMENT '对应表在配置库中',
        `para01` TEXT,
        `para02` TEXT,
        `para03` TEXT,
        `para04` TEXT,
        `para05` TEXT,
        `para06` TEXT,
        `para07` TEXT,
        `para08` TEXT,
        `para09` TEXT,
        `para10` TEXT,
        `para11` TEXT,
        `para12` TEXT,
        `para13` TEXT,
        `para14` TEXT,
        `para15` TEXT,
        `para16` TEXT,
        `para17` TEXT,
        `para18` TEXT,
        `para19` TEXT,
        `para20` TEXT,
        PRIMARY KEY (`id`),
        KEY `idx_logId` (`logId`)) engine=mrg_myisam union=() insert_method=last;
    ");
        
    set @sql_alt_mrga_text = concat(
        "ALTER TABLE ",@full_aname," engine=mrg_myisam union=(",@all_atables,") insert_method=last;"
    );
    set @sql_alt_mrgb_text = concat(
        "ALTER TABLE ",@full_bname," engine=mrg_myisam union=(",@all_btables,") insert_method=last;"
    );
    
    PREPARE creat_tablea FROM @sql_add_converge_atable;
    PREPARE creat_tableb FROM @sql_add_converge_btable;
    EXECUTE creat_tablea;
    EXECUTE creat_tableb;
    DEALLOCATE PREPARE creat_tablea;
    DEALLOCATE PREPARE creat_tableb;
    
    PREPARE alt_mrg_a FROM @sql_alt_mrga_text;
    PREPARE alt_mrg_b FROM @sql_alt_mrgb_text;
    EXECUTE alt_mrg_a;
    EXECUTE alt_mrg_b;
    DEALLOCATE PREPARE alt_mrg_a;
    DEALLOCATE PREPARE alt_mrg_b;
END */$$
DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
